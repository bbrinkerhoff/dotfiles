translateZoo() {
  local servers=(z00000604)


  for server in "${servers[@]}";do
    unset dns name cmdb num
    local num=$(sed -E 's/.*([0-9]{3})/\1/g' <<< "${server}")
    local cmdb=$(~/repos/tools/ops/scripts/cmdb/cmdbQuery.sh --short --device ${num})
    local dns=$(echo "${cmdb}"|sed '/dns/!d;s/.* //g')
    local name=$(echo "${cmdb}"|sed '/name/!d;s/.* //g')
    echo "${server} --> ${dns}"
  done; }
translateZoo
