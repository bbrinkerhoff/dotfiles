getLinks() {
  local file=${1}
  local filter=${2}
  local jqres=$(jq . ${file})
  local grepres=$(grep -i "${filter}" <<< "${jqres}")
  local sedres="[$(sed '$s/,$//;s/^ *"url": *//g' <<< "${grepres}")]"
  echo "${sedres}"| jq '.[]'
}
