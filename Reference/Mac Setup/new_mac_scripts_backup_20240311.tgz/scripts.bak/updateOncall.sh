#!/bin/bash

token='xoxp-2637490389-363746013424-1351045531188-10ae194075c8d005ecb57e14e3abb480'
groupID='SBYJURB8A'
slackUserID=;

getIDs(){
  local oncallJSON=`curl -ks "https://oncall.communitect.com:5000/getoncalls/"`
  local oncallEMAIL=`jq '.data[] as $parent | $parent["_parent"] | select(.name == "SysOps_schedule") | $parent | .onCallParticipants[]["name"]' <<< "$oncallJSON"`
  local oncallUSER=`sed 's/@.*//;s/"//' <<< $oncallEMAIL`

  local slackUserJSON=`curl -ks "https://slack.com/api/users.list?token=$token&pretty=1"`
  local jqFILTER="'.members[] | select(.name == \"$oncallUSER\") | .id'"
  slackUserID=`echo "$slackUserJSON" | eval jq $jqFILTER | sed 's/"//g'`
}

checkGroup(){
  getIDs
  local groupJSON=`curl -ks "https://slack.com/api/usergroups.users.list?token=$token&usergroup=$groupID&pretty=1"`
  local groupUSERS=`jq '.users[]' <<< "$groupJSON" | sed 's/"//g'`
  if [[ "$groupUSERS" = "$slackUserID" ]];then
    return 1
  else
    return 0
  fi
}


updateOncall(){
  if checkGroup;then
    if [[ -n $token ]] && [[ -n $groupID ]] && [[ -n $slackUserID ]];then
      curl -ks "https://slack.com/api/usergroups.users.update?token=$token&usergroup=$groupID&users=$slackUserID" >/dev/null 2>&1
    fi
  fi
}

updateOncall
