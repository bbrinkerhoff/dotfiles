
09:24:00 - ~/Desktop
 find . \! -type d -exec md5 -r {} \;|sort -k1|uniq -f2 -d
978c21111ae00b4463d04fe7220d5a99 ./IMG_0246.JPG


 find . \! -type d -exec md5 -r {} \;|sort -k1|uniq -f2 -d

find . \! -type d -exec md5 -r {} \;|sort -k1 > filelist.tmp



cleanDupes() {
  local IFS=$'\n' fileList="$(find . \! -type d -exec md5 -r {} \;|sort -k1)"
  local hashDupes=($(cut -d' ' -f1 <<< "${fileList}"|uniq -d))
  for hash in ${hashDupes[*]}
  do
    local oc rmList dupes=($(grep "${hash}" <<< "${fileList}" | perl -pe 's/^.*? //g;s/\ /\\ /g' | xargs ls -1cr))
    echo -e "${BLUE}Which file would you like to keep? (Files are listed oldest to newest)${RS}"
    menu ${dupes[*]} SKIP; oc=$?
    ((oc == ${#dupes[*]})) && continue
    rmList=($(sed $((oc+1))d <<< "${dupes[*]}"))
    echo
    rm -v "${rmList[@]// /\ }"
    echo -e "\n\n"
  done
}


sortMedia() {
  local mediaDir="${1:?No path specified}"
  echo "${Y}Moving media from ${mediaDir} to $(pwd)/Videos and $(pwd)/Images.${RS}"
  echo "Proceed?"
  menu no yes && return
  mkdir -p ./Videos ./Images
  echo "${G}Relocating all images...${RS}"
  find "${mediaDir}" -name '*' -exec file {} \; | grep -i -o -E '^.+: \w+ image' | cut -d: -f1 | sed 's/ /\\ /g' | xargs mv -v -t ./Images/
  echo "${G}Relocating all videos...${RS}"
  find "${mediaDir}" -name '*' -exec file {} \; | grep -i -o -E '^.+: \w+ media' | cut -d: -f1 | sed 's/ /\\ /g' | xargs mv -v -t ./Videos/
}

for dir in ./*;do cd "${dir}"; pwd; sortMedia ./; cd -;done