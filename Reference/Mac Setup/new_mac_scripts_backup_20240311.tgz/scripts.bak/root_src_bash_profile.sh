#! /bin/bash

eval SUDO_HOME=~${SUDO_USER}
if [ -f ${SUDO_HOME}/.bash_profile ];then
  . ${SUDO_HOME}/.bash_profile
fi
