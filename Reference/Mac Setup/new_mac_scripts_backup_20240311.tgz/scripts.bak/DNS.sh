#!/bin/bash

menu() {
  local ESC=$( printf "\033")
  cursor_blink_on()  { printf "$ESC[?25h"; }
  cursor_blink_off() { printf "$ESC[?25l"; }
  cursor_to()        { printf "$ESC[$1;${2:-1}H"; }
  print_option()     { printf "   $1 "; }
  print_selected()   { printf "  $ESC[7m $1 $ESC[27m"; }
  get_cursor_row()   { IFS=';' read -sdR -p $'\E[6n' ROW COL; echo ${ROW#*[}; }
  key_input()        { read -s -n3 key 2>/dev/null >&2
                       if [[ $key = "$ESC[A" ]]; then echo up;    fi
                       if [[ $key = "$ESC[B" ]]; then echo down;  fi
                       if [[ $key = ""     ]]; then echo enter; fi; }
  for opt; do printf "\n"; done
  local lastrow=`get_cursor_row`
  local startrow=$(($lastrow - $#))
  trap "cursor_blink_on; stty echo; printf '\n'; exit" 2
  cursor_blink_off
  local selected=0
  while true; do
      printf "\n"
      local idx=0
      for opt; do
          cursor_to $(($startrow + $idx))
          if [ $idx -eq $selected ]; then
              print_selected "$opt"
          else
              print_option "$opt"
          fi
          ((idx++))
      done
      case `key_input` in
          enter) break;;
          up)    ((selected--));
                 if [ $selected -lt 0 ]; then local selected=$(($# - 1)); fi;;
          down)  ((selected++));
                 if [ $selected -ge $# ]; then local selected=0; fi;;
      esac
  done
  cursor_to $lastrow
  printf "\n"
  cursor_blink_on
  return $selected; }

DNS() {
  local nodes=(1 2 3)
  read -ep "service name: " service
  read -ep "server type: " servertype
  read -ep "current host name: " host
  echo "node number:"
  menu ${nodes[@]}
  local node=${nodes[$?]}
  local service="$service""0""$node"
  local host=`host $host|tail -n1|sed 's/.* //'`
  printf "%-40s%-8s%-8s%-16s%-s" "hq-prod-$service" "IN" "A" "$host" "; HQ Prod $servertype server"
  printf "%-40s%-8s%-8s%-16s%-s" "hq-prod-$service" "IN" "A" "$host" "; HQ Prod $servertype server"|pbcopy; }

DNS
