#!/bin/bash

# Written by:
# Date written:
# Objective: 

#################
## Global Vars ##
#################
VAR1=; VAR2=; ARR1=()


################
## Color Vars ##
################
GREEN=`tput -T xterm-256color setaf 2;tput -T xterm-256color bold`
RED=`tput -T xterm-256color setaf 1;tput -T xterm-256color bold`
YELLOW=`tput -T xterm-256color setaf 3;tput -T xterm-256color bold`
BLUE=`tput -T xterm-256color setaf 4;tput -T xterm-256color bold`
RESET=`tput -T xterm-256color sgr0;tput -T xterm-256color bold`


###########################
## Text Output Functions ##
###########################
_error() { printf "${RED} * ERROR${RESET}: %s\n" "$@" 1>&2;} # echo 'ERROR' text to stderr
_info()  { printf "${GREEN} *  INFO${RESET}: %s\n" "$@";}    # echo 'INFO' text to stdout
_echo()  { local color=`tr [a-z] [A-Z] <<< $1`;shift;echo "${!color}$@${RESET}"; } # echo with specified color


###################
## Menu Function ##
###################
menu() {
  local ESC=$( printf "\033")
  cursor_blink_on()  { printf "$ESC[?25h"; }
  cursor_blink_off() { printf "$ESC[?25l"; }
  cursor_to()        { printf "$ESC[$1;${2:-1}H"; }
  print_option()     { printf "   $1 "; }
  print_selected()   { printf "  $ESC[7m $1 $ESC[27m"; }
  get_cursor_row()   { IFS=';' read -sdR -p $'\E[6n' ROW COL; echo ${ROW#*[}; }
  key_input()        { read -s -n3 key 2>/dev/null >&2
                       if [[ $key = "$ESC[A" ]]; then echo up;    fi
                       if [[ $key = "$ESC[B" ]]; then echo down;  fi
                       if [[ $key = ""     ]]; then echo enter; fi; }
  for opt; do printf "\n"; done
  local lastrow=`get_cursor_row`
  local startrow=$(($lastrow - $#))
  trap "cursor_blink_on; stty echo; printf '\n'; exit" 2
  cursor_blink_off
  local selected=0
  while true; do
      printf "\n"
      local idx=0
      for opt; do
          cursor_to $(($startrow + $idx))
          if [ $idx -eq $selected ]; then
              print_selected "$opt"
          else
              print_option "$opt"
          fi
          ((idx++))
      done
      case `key_input` in
          enter) break;;
          up)    ((selected--));
                 if [ $selected -lt 0 ]; then local selected=$(($# - 1)); fi;;
          down)  ((selected++));
                 if [ $selected -ge $# ]; then local selected=0; fi;;
      esac
  done
  cursor_to $lastrow
  printf "\n"
  cursor_blink_on
  return $selected; }


###############
## Functions ##
###############
#setVARS() {}
#functionONE() {}


###################
## Help Function ##
###################
showHELP() {
  echo "${YELLOW}Options:${BLUE}"
  echo "    -h,--help                         Show this help menu."
  echo "    -a,--arg                          Sets an arg."
  echo
  echo "${YELLOW}Usage:${BLUE}"
  echo "    ./script.sh"
  echo "    ./script.sh [-h,--help]"
  echo "    ./script.sh [-a,--arg][arg]"
  echo "${RESET}"; exit 0; }


##################
## Script Flags ##
##################
while test $# -gt 0;do
      case $1 in
              -h|--help)
                showHELP
                ;;
              -a|--arg)
                shift
                arg=$1
                shift
                ;;
              *)
                _error "'$1' is not a valid argument."
                _info "A list of valid arguments can be found using -h or --help"
                exit 1
                ;;
      esac
done


#defaultFUNCTION # Run default function after script flags/args have been ingested
#exit 0 
