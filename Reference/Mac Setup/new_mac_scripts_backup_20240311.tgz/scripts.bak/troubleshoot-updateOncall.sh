troubleshootGroups(){
  GREEN=$(tput -T xterm-256color setaf 2;tput -T xterm-256color bold)
  RED=$(tput -T xterm-256color setaf 1;tput -T xterm-256color bold)
  YELLOW=$(tput -T xterm-256color setaf 3;tput -T xterm-256color bold)
  RESET=$(tput -T xterm-256color sgr0;tput -T xterm-256color bold)
  _error() { printf "${RED} * ERROR${RESET}: %s\n" "$@" 1>&2;} # echo 'ERROR' text to stderr
  _info()  { printf "${GREEN} *  INFO${RESET}: %s\n" "$@";}    # echo 'INFO' text to stdout
  _echo()  { local color=$(tr [a-z] [A-Z] <<< $1);shift;echo "${!color}$@${RESET}"; } # echo with specified color
  checkGroupMembersTest(){
    _info "Running function 'checkGroupMembers'"
    # Check if the oncall user is already the only user in their user group
    local IFS=$'\n'; local groupID=$1; shift; local userIDs=($(sort <<< "$*"))
    _info "groupID: ${groupID}"
    _info "userIDs: ${userIDs[@]}"
    local jqFilter="'.usergroups[] | select(.id == \"$groupID\")|.user_count'"
    _info "jqFilter: ${jqFilter}"
    local userCount=$(echo "$slackGroups"|eval jq $jqFilter)
    if [[ $userCount -gt 0 ]];then
      _info "userCount is > 0 -- userCount: ${userCount}"
      local jqFilter="'.usergroups[] | select(.id == \"$groupID\")|.users[]'"
      _info "jqFilter: ${jqFilter}"
      local groupMembers=($(echo "$slackGroups"|eval jq $jqFilter))
      _info "groupMembers (post JQ filter): ${groupMembers[@]}"
      local groupMembers=($(echo "${groupMembers[*]}"|sort|sed 's/"//g'))
      _info "groupMembers (post sed filter): ${groupMembers[@]}"
      _info "${groupMembers[@]} == ${userIDs[@]}"
      [[ ${groupMembers[@]} == ${userIDs[@]} ]]; _info "Out-code: $?"
      [[ ${groupMembers[@]} == ${userIDs[@]} ]]; return $?
    else
      _error "userCount is <= 0 -- userCount: ${userCount}"
      return 1
    fi; }
  updateGroupMembersTest() {
    _info "Running function 'updateGroupMembers'"
    # Use REST command to update the members of the given slack user group to be only the on-call user for that team
    local groupID=$1; shift; local userIDs=($@); local userString=$(joinBy "%" "${userIDs[@]}"|sed 's/%/%2C/g'); [[ -n $userString && -n $groupID ]] && \
    _info "groupID: ${groupID}"; _info "userIDs: ${userIDs[@]}"; _info "userString: ${userString}"
    _info "Command: curl -ks \"https://slack.com/api/usergroups.users.update?token=$slackToken&usergroup=$groupID&users=$userString\" >/dev/null 2>&1"; }

  updateOncallGroupsTest() {
    # Loop through every team in the "teams" array and update it's corresponding Slack user group
    if getJSON;then
      _info "Function 'getJSON' successful"
      for team in "${teams[@]}";do
        _info "team: ${team}"
        local teamLower=$(tr [:upper:] [:lower:] <<< "$team");
        _info "teamLower: ${teamLower}"
        local handle=$(sed 's/_/-/g;s/ /-/g' <<< "oncall-$teamLower")
        _info "handle: ${handle}"
        local schedule=$team\_schedule
        _info "schedule: ${schedule}"
        local userEmails=($(getUserEmails "$schedule"))
        _info "userEmails: ${userEmails[@]}"
        local userNames=($(sed 's/@.*//g' <<< "$(joinBy $'\n' ${userEmails[@]})"))
        _info "userNames: ${userNames[@]}"
        local groupID=$(getGroupID "$handle")
        _info "groupID: ${groupID}"
        local userIDs=($(getUserIDs $groupID ${userNames[@]}))
        _info "userIDs: ${userIDs[@]}"
        # The 'checkGroupMembers' function will return true if all the members to be added are already the users in the group
        if ! checkGroupMembersTest "$groupID" "${userIDs[@]}";then
          _error "Function 'updateGroupMembers' set to run"
          updateGroupMembersTest "$groupID" "${userIDs[@]}"
        else
          _info "Function 'updateGroupMembers' would not need to run"
        fi
        _echo yellow "----------------------"
      done
    fi; }

  updateSpecialGroupsTest() {
    # Separate function to update only the on-call usergroup for because it has a handle that doesn't match the team name
    if getJSON;then
      _info "Function 'getJSON' successful"
      # Ensure that the amount of items in the 'specialTeams' array is a factor of 3
      if ! (( $# % 3 ));then
        # Every loop will shift 3 places in the 'specialTeams' array to populate the corresponding team, schedule, and handle vars until the array is empty
        while test $# -gt 0;do
          local team="$1"; shift
          _info "team: ${team}"
          local schedule="$1"; shift
          _info "schedule: ${schedule}"
          local handle="$1"; shift
          _info "handle: ${handle}"
          local userEmails=($(getUserEmails "$schedule"))
          _info "userEmails: ${userEmails[@]}"
          local userNames=($(sed 's/@.*//g' <<< "$(joinBy $'\n' ${userEmails[@]})"))
          _info "userNames: ${userNames[@]}"
          local groupID=$(getGroupID "$handle")
          _info "groupID: ${groupID}"
          local userIDs=($(getUserIDs $groupID ${userNames[@]}))
          _info "userIDs: ${userIDs[@]}"
          if ! checkGroupMembersTest "$groupID" "${userIDs[@]}";then
            _error "Function 'updateGroupMembers' set to run"
            updateGroupMembersTest "$groupID" "${userIDs[@]}"
          else
            _info "Function 'updateGroupMembers' would not need to run"
          fi
          _echo yellow "----------------------"
        done
      fi
    fi; }

    _echo green "** STARTING TROUBLESHOOTING **"
    _echo yellow "Testing function 'updateOncallGroups'"
    updateOncallGroupsTest
    _echo yellow "Testing function 'updateSpecialGroups'"
    updateSpecialGroupsTest "${specialTeams[@]}"
    _echo green "** ENDING TROUBLESHOOTING **"

}
