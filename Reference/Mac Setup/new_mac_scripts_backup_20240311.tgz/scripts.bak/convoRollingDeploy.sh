#!/usr/bin/env bash
convoRollingDeploy()
{
  read -ep "Specify version: " version
  local delay hosts
  hosts=(ut-prod-convo0{1..3})
  delay=300

  for host in "${hosts[@]}"
  do
    echo -e "\nStarting deploy to '${host}'..."
    if [[ -n ${version+x} ]]
    then
      ssh -q -t "${host}" "sudo systemctl stop srtomcat; sleep 3; sudo systemctl status srtomcat; sudo yum clean all && sudo yum upgrade sr-*-${version} -y --skip-broken; sudo systemctl start srtomcat; sleep 3; sudo systemctl status srtomcat"
    else
      ssh -q -t "${host}" "sudo systemctl stop srtomcat; sleep 3; sudo systemctl status srtomcat; sudo yum clean all && sudo yum upgrade -y --skip-broken; sudo systemctl start srtomcat; sleep 3; sudo systemctl status srtomcat"
    fi
    echo -e "Deploy to '${host}' complete.\n"

    if [[ "${host}" != "${hosts[-1]}" ]]
    then
      echo "Sleeping for ${delay} seconds before proceeding..."
      sleep ${delay}
    fi
  done

  echo -e "\n\nRolling deployment complete."
}

convoRollingDeploy