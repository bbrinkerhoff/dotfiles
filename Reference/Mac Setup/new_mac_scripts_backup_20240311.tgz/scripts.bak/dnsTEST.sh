dnsTEST() {
  local servers=($@)
  local cnames=()
  local anames=()
  for server in ${servers[@]};do
    if host ${server/%/.communitect.com} 10.0.0.111 | grep -q 'is an alias';then
      cnames+=(${server})
    else
      anames+=(${server})
    fi
  done
  local IFS=$'\n'
  echo "${GREEN}CNAMEs:${RESET}"
  echo "${cnames[*]/#/  - }"
  echo
  echo "${RED}A Records:${RESET}"
  echo "${anames[*]/#/  - }"
}
