#!/usr/bin/env bash


#################
## Global Vars ##
#################
logDir="/var/log/sr-notify-api"
origDisk="$(df -h ${logDir}|tail -n1 | awk '{print $5}')"
date=$(date "+%Y-%m-%d")
regex="^.*[0-9]{4}-[0-9]{2}-[0-9]{2}.*\.(log|txt|backup)$"

###########################
## Text Output Functions ##
###########################
_txt()   { tput -T xterm-256color $@;}                                   # set text attributes
_fg()    { _txt setaf ${1};}                                             # set the foreground text color
_bg()    { _txt setab ${1};}                                             # set the background text color
_join()  { local IFS=${1} ; printf "${*:2}";}                            # join arguments with ${1} delimiter
_info()  { local IFS=$'\n'; printf "${G} *  INFO${RS}: %s\n" "$*";}      # print 'INFO' text to stdout
_warn()  { local IFS=$'\n'; printf "${Y} *  WARN${RS}: %s\n" "$*";}      # print 'WARN' text to stdout
_error() { local IFS=$'\n'; printf "${R} * ERROR${RS}: %s\n" "$*" 1>&2;} # print 'ERROR' text to stderr
_print() { local IFS=$'\n' c="${1^^}"; c="${!c}"                         # print arguments with an optional color arg
           shift 0${c:+1} ; printf "$c%b\n"                  "$*";}      #+to stdout separated by a newline


######################
## Text Output Vars ##
######################
BLD=$(_txt bold) DIM=$(_txt dim) # Bold / Dim
UL=$(_txt smul) ITL=$(_txt sitm) # Underline / Italic
RS=$(_txt sgr0)                  # Reset (Unset attributes)
R=$(_fg 9) G=$(_fg 10)             # Red / Green
B=$(_fg 12) Y=$(_fg 11)            # Blue / Yellow


###################
## Menu Function ##
###################
menu() {
  local ESC=$(printf "\033")
  cursor_blink_on()  { printf "%s" "${ESC}[?25h"                               ; }
  cursor_blink_off() { printf "%s" "${ESC}[?25l"                               ; }
  cursor_to()        { printf "%s" "${ESC}[$1;${2:-1}H"                        ; }
  print_option()     { printf "%s" "   $1 "                                    ; }
  print_selected()   { printf "%s" "  ${ESC}[7m $1 ${ESC}[27m"                 ; }
  get_cursor_row()   { IFS=';' read -rsdR -p $'\E[6n' ROW COL; echo "${ROW#*[}"; }
  key_input()        { read -rs -n3 key 2>/dev/null
                       if [[ "${key}" = "${ESC}[A" ]]; then echo up   ; fi
                       if [[ "${key}" = "${ESC}[B" ]]; then echo down ; fi
                       if [[ "${key}" = ""         ]]; then echo enter; fi     ; }
  for opt; do printf "\n"; done
  local lastrow=$(get_cursor_row)
  local startrow=$((lastrow - $#))
  trap "cursor_blink_on; stty echo; printf '\n'; exit" 2
  cursor_blink_off
  local selected=0
  while true; do
      printf "\n"
      local idx=0
      for opt; do
          cursor_to $((startrow + idx))
          if [ ${idx} -eq ${selected} ]; then
              print_selected "${opt}"
          else
              print_option "${opt}"
          fi
          ((idx++))
      done
      case $(key_input) in
          enter) break;;
          up)    ((selected--));
                 if [ ${selected} -lt 0 ]; then local selected=$(($# - 1)); fi;;
          down)  ((selected++));
                 if [ ${selected} -ge $# ]; then local selected=0; fi;;
      esac
  done
  cursor_to "${lastrow}"
  printf "\n"
  cursor_blink_on
  return ${selected}; }



compressLOGS() {
  df -h ${logDir}
  echo
  _info "Searching for logs in: ${logDir}"
  echo
  find ${logDir} -type f -regextype posix-extended -regex "${regex}" ! -regex "^.*${date}.*$"
  echo
  echo "${Y}Would you like to continue?${RS}"
  if menu yes no
  then
    _info "Compressing logs at ${logDir}"
    echo
    find ${logDir} -type f -regextype posix-extended -regex "${regex}" ! -regex "^.*${date}.*$" -exec bzip2 -vf {} \;
    _info "Log compression complete"
    echo
    df -h ${logDir}
    echo
    newDisk=$(df -h ${logDir}|tail -n1 | awk '{print $5}')
    _info "Disk use ${origDisk} -> ${newDisk}"
  else
    _warn "Aborting log compression."
  fi
}

compressLOGS
