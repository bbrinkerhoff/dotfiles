delFILES() {
  local files=(
    /opt/subfiles/1/0/cosmetic2.jpg
    /opt/subfiles/1/0/cosmetic2.png
    /opt/subfiles/1/0/customImages/cosmetic2.jpg
    /opt/subfiles/1/0/customImages/cosmetic2.png
    /opt/subfiles/1/1/cosmetic2.jpg
    /opt/subfiles/1/1/cosmetic2.png
    /opt/subfiles/1/1/customImages/cosmetic2.jpg
    /opt/subfiles/1/1/customImages/cosmetic2.png
    /opt/subfiles/1/10/cosmetic2.jpg
    /opt/subfiles/1/10/cosmetic2.png
    /opt/subfiles/1/10/customImages/cosmetic2.jpg
    /opt/subfiles/1/10/customImages/cosmetic2.png
    /opt/subfiles/1/11/cosmetic2.jpg
    /opt/subfiles/1/11/cosmetic2.png
    /opt/subfiles/1/11/customImages/cosmetic2.jpg
    /opt/subfiles/1/11/customImages/cosmetic2.png
    /opt/subfiles/1/12/customImages/cosmetic2.jpg
    /opt/subfiles/1/12/customImages/cosmetic2.png
    /opt/subfiles/1/2/customImages/cosmetic2.jpg
    /opt/subfiles/1/2/customImages/cosmetic2.png
    /opt/subfiles/1/3/customImages/cosmetic2.jpg
    /opt/subfiles/1/3/customImages/cosmetic2.png
    /opt/subfiles/1/4/cosmetic2.jpg
    /opt/subfiles/1/4/cosmetic2.png
    /opt/subfiles/1/4/customImages/cosmetic2.jpg
    /opt/subfiles/1/4/customImages/cosmetic2.png
    /opt/subfiles/1/5/customImages/cosmetic2.jpg
    /opt/subfiles/1/5/customImages/cosmetic2.png
    /opt/subfiles/1/6/customImages/cosmetic2.jpg
    /opt/subfiles/1/6/customImages/cosmetic2.png
    /opt/subfiles/1/7/customImages/cosmetic2.jpg
    /opt/subfiles/1/7/customImages/cosmetic2.png
    /opt/subfiles/1/8/customImages/cosmetic2.jpg
    /opt/subfiles/1/8/customImages/cosmetic2.png
    /opt/subfiles/1/9/customImages/cosmetic2.jpg
    /opt/subfiles/1/9/customImages/cosmetic2.png
    /opt/subfiles/1/customImages/cosmetic2.jpg
    /opt/subfiles/1/customImages/cosmetic2.png)
  echo "Files to be yeeted:"; local IFS=$'\n'
  echo "${files[*]}"
  unset IFS
  read -p "ready to proceed."
  rm -vf ${files[@]}
}

backupFILES() {
  local files=(
    /opt/subfiles/1/0/cosmetic2.jpg
    /opt/subfiles/1/0/cosmetic2.png
    /opt/subfiles/1/0/customImages/cosmetic2.jpg
    /opt/subfiles/1/0/customImages/cosmetic2.png
    /opt/subfiles/1/1/cosmetic2.jpg
    /opt/subfiles/1/1/cosmetic2.png
    /opt/subfiles/1/1/customImages/cosmetic2.jpg
    /opt/subfiles/1/1/customImages/cosmetic2.png
    /opt/subfiles/1/10/cosmetic2.jpg
    /opt/subfiles/1/10/cosmetic2.png
    /opt/subfiles/1/10/customImages/cosmetic2.jpg
    /opt/subfiles/1/10/customImages/cosmetic2.png
    /opt/subfiles/1/11/cosmetic2.jpg
    /opt/subfiles/1/11/cosmetic2.png
    /opt/subfiles/1/11/customImages/cosmetic2.jpg
    /opt/subfiles/1/11/customImages/cosmetic2.png
    /opt/subfiles/1/12/customImages/cosmetic2.jpg
    /opt/subfiles/1/12/customImages/cosmetic2.png
    /opt/subfiles/1/2/customImages/cosmetic2.jpg
    /opt/subfiles/1/2/customImages/cosmetic2.png
    /opt/subfiles/1/3/customImages/cosmetic2.jpg
    /opt/subfiles/1/3/customImages/cosmetic2.png
    /opt/subfiles/1/4/cosmetic2.jpg
    /opt/subfiles/1/4/cosmetic2.png
    /opt/subfiles/1/4/customImages/cosmetic2.jpg
    /opt/subfiles/1/4/customImages/cosmetic2.png
    /opt/subfiles/1/5/customImages/cosmetic2.jpg
    /opt/subfiles/1/5/customImages/cosmetic2.png
    /opt/subfiles/1/6/customImages/cosmetic2.jpg
    /opt/subfiles/1/6/customImages/cosmetic2.png
    /opt/subfiles/1/7/customImages/cosmetic2.jpg
    /opt/subfiles/1/7/customImages/cosmetic2.png
    /opt/subfiles/1/8/customImages/cosmetic2.jpg
    /opt/subfiles/1/8/customImages/cosmetic2.png
    /opt/subfiles/1/9/customImages/cosmetic2.jpg
    /opt/subfiles/1/9/customImages/cosmetic2.png
    /opt/subfiles/1/customImages/cosmetic2.jpg
    /opt/subfiles/1/customImages/cosmetic2.png)
  echo "Files to be backed up:"; local IFS=$'\n'
  echo "${files[*]}"
  unset IFS
  read -p "ready to proceed."
  for file in "${files[@]}";do
    if mkdir -pv ./${file%/*};then
      cp -pv ${file} ./${file%/*}
    fi
  done
}

moveFILES() {
  local group1=(
    appSubfiles/web/1/0/cosmetic2.jpg
    appSubfiles/web/1/0/cosmetic2.png)
  local group1dest='/opt/subfiles/1/0/'

  local group2=(
    appSubfiles/web/1/0/customImages/cosmetic2.jpg
    appSubfiles/web/1/0/customImages/cosmetic2.png)
  local group2dest='/opt/subfiles/1/0/customImages/'

  local group3=(
    appSubfiles/web/1/1/cosmetic2.jpg
    appSubfiles/web/1/1/cosmetic2.png)
  local group3dest='/opt/subfiles/1/1/'

  local group4=(
    appSubfiles/web/1/1/customImages/cosmetic2.jpg
    appSubfiles/web/1/1/customImages/cosmetic2.png)
  local group4dest='/opt/subfiles/1/1/customImages/'

  local group5=(
    appSubfiles/web/1/10/cosmetic2.jpg
    appSubfiles/web/1/10/cosmetic2.png)
  local group5dest='/opt/subfiles/1/10/'

  local group6=(
    appSubfiles/web/1/10/customImages/cosmetic2.jpg
    appSubfiles/web/1/10/customImages/cosmetic2.png)
  local group6dest='/opt/subfiles/1/10/customImages/'

  local group7=(
    appSubfiles/web/1/11/cosmetic2.jpg
    appSubfiles/web/1/11/cosmetic2.png)
  local group7dest='/opt/subfiles/1/11/'

  local group8=(
    appSubfiles/web/1/11/customImages/cosmetic2.jpg
    appSubfiles/web/1/11/customImages/cosmetic2.png)
  local group8dest='/opt/subfiles/1/11/customImages/'

  local group9=(
    appSubfiles/web/1/12/customImages/cosmetic2.jpg
    appSubfiles/web/1/12/customImages/cosmetic2.png)
  local group9dest='/opt/subfiles/1/12/customImages/'

  local group10=(
    appSubfiles/web/1/2/customImages/cosmetic2.jpg
    appSubfiles/web/1/2/customImages/cosmetic2.png)
  local group10dest='/opt/subfiles/1/2/customImages/'

  local group11=(
    appSubfiles/web/1/3/customImages/cosmetic2.jpg
    appSubfiles/web/1/3/customImages/cosmetic2.png)
  local group11dest='/opt/subfiles/1/3/customImages/'

  local group12=(
    appSubfiles/web/1/4/cosmetic2.jpg
    appSubfiles/web/1/4/cosmetic2.png)
  local group12dest='/opt/subfiles/1/4/'

  local group13=(
    appSubfiles/web/1/4/customImages/cosmetic2.jpg
    appSubfiles/web/1/4/customImages/cosmetic2.png
    appSubfiles/web/1/4/customImages/OPTICAL_family_2020_4.png
    appSubfiles/web/1/4/customImages/OPTICAL_family_2020_3.png
    appSubfiles/web/1/4/customImages/OPTICAL_family_2020_2.png
    appSubfiles/web/1/4/customImages/LASIK_2020_4.png
    appSubfiles/web/1/4/customImages/LASIK_2020_3.png
    appSubfiles/web/1/4/customImages/LASIK_2020_2.png
    appSubfiles/web/1/4/customImages/LASIK_2020_1.png
    appSubfiles/web/1/4/customImages/CATARACTS_2020_2.png)
  local group13dest='/opt/subfiles/1/4/customImages/'

  local group14=(
    appSubfiles/web/1/5/customImages/cosmetic2.jpg
    appSubfiles/web/1/5/customImages/cosmetic2.png)
  local group14dest='/opt/subfiles/1/5/customImages/'

  local group15=(
    appSubfiles/web/1/6/customImages/cosmetic2.jpg
    appSubfiles/web/1/6/customImages/cosmetic2.png)
  local group15dest='/opt/subfiles/1/6/customImages/'

  local group16=(
    appSubfiles/web/1/7/customImages/cosmetic2.jpg
    appSubfiles/web/1/7/customImages/cosmetic2.png)
  local group16dest='/opt/subfiles/1/7/customImages/'

  local group17=(
    appSubfiles/web/1/8/customImages/cosmetic2.jpg
    appSubfiles/web/1/8/customImages/cosmetic2.png)
  local group17dest='/opt/subfiles/1/8/customImages/'

  local group18=(
    appSubfiles/web/1/9/customImages/cosmetic2.jpg
    appSubfiles/web/1/9/customImages/cosmetic2.png)
  local group18dest='/opt/subfiles/1/9/customImages/'

  local group19=(
    appSubfiles/web/1/customImages/cosmetic2.jpg
    appSubfiles/web/1/customImages/cosmetic2.png)
  local group19dest='/opt/subfiles/1/customImages/'

  if [[ -d ./deploy_files ]];then
    read -p "deploy file dir found. ready to proceed."
    cd ./deploy_files; pwd
    for num in {1..19};do
      local arrVar="group${num}[@]"
      local files=${!arrVar}
      local destVar="group${num}dest"
      local dest=${!destVar}
      echo "Group ${num} files:"
      local IFS=$'\n'
      echo "${files[*]}"
      unset IFS
      read -p "ready to proceed"
      ls -l ${files[@]}; echo
      cp -pv ${files[@]} ${dest}
      echo -e "\n\n"
    done
  fi
}









permFILES() {
  local refFILE=$(find /opt/subfiles/1/0/ -maxdepth 1 -type f | head -n1)
  read -p "REF FILE=${refFILE}. ready to proceed."
  chown -cR --reference=${refFILE} ./
  chmod -cR --reference=${refFILE} ./
}











copyFILES() {
  local files=(
    appSubfiles/web/1/0/cosmetic2.jpg
    appSubfiles/web/1/0/cosmetic2.png
    appSubfiles/web/1/0/customImages/cosmetic2.jpg
    appSubfiles/web/1/0/customImages/cosmetic2.png
    appSubfiles/web/1/1/cosmetic2.jpg
    appSubfiles/web/1/1/cosmetic2.png
    appSubfiles/web/1/1/customImages/cosmetic2.jpg
    appSubfiles/web/1/1/customImages/cosmetic2.png
    appSubfiles/web/1/10/cosmetic2.jpg
    appSubfiles/web/1/10/cosmetic2.png
    appSubfiles/web/1/10/customImages/cosmetic2.jpg
    appSubfiles/web/1/10/customImages/cosmetic2.png
    appSubfiles/web/1/11/cosmetic2.jpg
    appSubfiles/web/1/11/cosmetic2.png
    appSubfiles/web/1/11/customImages/cosmetic2.jpg
    appSubfiles/web/1/11/customImages/cosmetic2.png
    appSubfiles/web/1/12/customImages/cosmetic2.jpg
    appSubfiles/web/1/12/customImages/cosmetic2.png
    appSubfiles/web/1/2/customImages/cosmetic2.jpg
    appSubfiles/web/1/2/customImages/cosmetic2.png
    appSubfiles/web/1/3/customImages/cosmetic2.jpg
    appSubfiles/web/1/3/customImages/cosmetic2.png
    appSubfiles/web/1/4/cosmetic2.jpg
    appSubfiles/web/1/4/cosmetic2.png
    appSubfiles/web/1/4/customImages/cosmetic2.jpg
    appSubfiles/web/1/4/customImages/cosmetic2.png
    appSubfiles/web/1/4/customImages/OPTICAL_family_2020_4.png
    appSubfiles/web/1/4/customImages/OPTICAL_family_2020_3.png
    appSubfiles/web/1/4/customImages/OPTICAL_family_2020_2.png
    appSubfiles/web/1/4/customImages/LASIK_2020_4.png
    appSubfiles/web/1/4/customImages/LASIK_2020_3.png
    appSubfiles/web/1/4/customImages/LASIK_2020_2.png
    appSubfiles/web/1/4/customImages/LASIK_2020_1.png
    appSubfiles/web/1/4/customImages/CATARACTS_2020_2.png
    appSubfiles/web/1/5/customImages/cosmetic2.jpg
    appSubfiles/web/1/5/customImages/cosmetic2.png
    appSubfiles/web/1/6/customImages/cosmetic2.jpg
    appSubfiles/web/1/6/customImages/cosmetic2.png
    appSubfiles/web/1/7/customImages/cosmetic2.jpg
    appSubfiles/web/1/7/customImages/cosmetic2.png
    appSubfiles/web/1/8/customImages/cosmetic2.jpg
    appSubfiles/web/1/8/customImages/cosmetic2.png
    appSubfiles/web/1/9/customImages/cosmetic2.jpg
    appSubfiles/web/1/9/customImages/cosmetic2.png
    appSubfiles/web/1/customImages/cosmetic2.jpg
    appSubfiles/web/1/customImages/cosmetic2.png)

  local prefix=/Users/bbrinkerhoff/repos/deploys/smilereminder3
  for file in ${files[@]};do
    if mkdir -pv ./${file%/*};then
      cp -v ${prefix}/${file} ./${file}
    fi
  done
}
