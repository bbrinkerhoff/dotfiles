migrateSalt() {
  while [[ -z ${node+x} || -z ${master+x} ]];do
    [[ -z ${node+x} ]] && read -ep "New Minion ID: " node
    [[ -z ${master+x} ]] && read -ep "New Salt Master: " master
  done
  local saltDir="/etc/salt"
  local minionConf="${saltDir}/minion"
  local minionIDFile="${saltDir}/minion_id"
  local grainsFile="${saltDir}/grains"
  local masterPub="${saltDir}/pki/minion/minion_master.pub"
  local minionConfDir="${saltDir}/minion.d"
  local firewalldServices=(postgresql)
  local minionConfTemplate="id: %ID%
master:
  - %MASTER%
master_alive_interval: 30
retry_dns: 30
hash_type: sha256

use_superseded:
  - module.run"

  echo "Delete following key from old master:"
  salt-call grains.get id
  echo "Stopping salt-minion service"
  systemctl stop salt-minion
  systemctl status salt-minion
  echo "Clearing/Updating salt minion config"
  echo > ${grainsFile}
  rm -f ${minionIDFile}
  rm -f ${masterPub}
  find ${minionConfDir} -type f -exec rm -vf {} \;
  sed -e "s;%ID%;${node};g" -e "s;%MASTER%;${master};g" <<< "${minionConfTemplate}" > ${minionConf}
  echo "Starting salt-minion service"
  systemctl start salt-minion
  systemctl status salt-minion
  echo "Clearing salt-minion cache"
  salt-call --local saltutil.clear_cache
  salt-call saltutil.sync_all
  echo "Restarting salt-minion service"
  systemctl stop salt-minion
  systemctl status salt-minion
  systemctl start salt-minion
  systemctl status salt-minion
  read -p "Salt-Minion service started. Accept '${node}' key on ${master}. hit enter when ready."
  echo "Testing enrollment"
  salt-call test.ping
  read -p "Running salt-minion state. 1/3 hit enter when ready."
  salt-call state.sls modules.salt.minion --state-output=mixed
  read -p "Running salt-minion state. 2/3 hit enter when ready."
  salt-call state.sls modules.salt.minion --state-output=mixed
  read -p "Running salt-minion state. 3/3 hit enter when ready."
  salt-call state.sls modules.salt.minion --state-output=mixed
  read -p "Running salt-minion profile.common state. 1/2 hit enter when ready."
  salt-call state.sls profile.common --state-output=mixed
  read -p "Running salt-minion profile.common state. 2/2 hit enter when ready."
  salt-call state.sls profile.common --state-output=mixed
  echo "Migrating firewall services from iptables to firewalld"
  systemctl stop iptables; systemctl disable iptables
  systemctl start firewalld; systemctl enable firewalld
  if [[ -n ${firewalldServices[@]+x} ]];then
    for service in ${firewalldServices[@]};do
      echo "Adding '${service}' to firewalld"
      firewall-cmd --add-service ${service} --permanent
    done
    echo "Reloading/applying firewall rules"
    firewall-cmd --reload
    firewall-cmd --list-all
  fi
  echo
  echo "All commands have been run. Restart box if needed and run profile.common if needed"
  echo "Don't forget to stop/disable winbind"
}


postReboot() {
  echo leaving realm
  net ads leave -U bbrinkerhoff
  echo "Disabling winbind"
  systemctl stop winbind
  systemctl disable winbind
  echo "Disabling nrpe"
  systemctl stop nrpe
  systemctl disable nrpe
  echo "Enabling sssd"
  systemctl start sssd
  systemctl enable sssd
  echo "Running realmd state"
  salt-call state.sls modules.realmd --state-output=mixed
  echo "Restarting sssd"
  systemctl restart sssd
  systemctl status sssd
  echo "Listing realms"
  realm list
  echo "Running authorized keys and bash"
  salt-call state.sls profile.common.Linux.authorized_keys,modules.bash --state-output=mixed
  echo "Showing firewall rules"
  firewall-cmd --list-all
  echo "ALL DONE"
}