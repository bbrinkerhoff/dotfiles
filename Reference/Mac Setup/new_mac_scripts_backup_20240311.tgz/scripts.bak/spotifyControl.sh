 #!/bin/bash


#################
## Global Vars ##
#################
refreshToken='AQAlMIGfjkmlC6w_GfZoy2JVGGfUx0I43yyisIwkU7YxGEHlRBEo-3i301Ja9OYaK3CQF9WWBe4rmWG00PpwR-feKYbzlWXafROnPged8YsOV1ugEKB41h_JI47cJUNRs6u04A'
contentURL="https://open.spotify.com/playlist/5g9RfikhCKd60Yn5StrclA?si=3aba8ae5b49a469e"
spotifyURI="$(echo "${contentURL}"|sed 's/.*\.com\//spotify:/g;s/\//:/g;s/\?.*//g')"
deviceName='Master Bedroom AppleTV'
volumeLevel=75
receiverIP=192.168.1.16
access_token=;


################
## Color Vars ##
################
GREEN=$(tput -T xterm-256color setaf 2;tput -T xterm-256color bold)
RED=$(tput -T xterm-256color setaf 1;tput -T xterm-256color bold)
YELLOW=$(tput -T xterm-256color setaf 3;tput -T xterm-256color bold)
BLUE=$(tput -T xterm-256color setaf 4;tput -T xterm-256color bold)
RESET=$(tput -T xterm-256color sgr0;tput -T xterm-256color bold)


###########################
## Text Output Functions ##
###########################
_error() { printf "${RED} * ERROR${RESET}: %s\n" "$@" 1>&2;} # echo 'ERROR' text to stderr
_info()  { printf "${GREEN} *  INFO${RESET}: %s\n" "$@";}    # echo 'INFO' text to stdout
_echo()  { local color=$(tr [a-z] [A-Z] <<< $1);shift;echo "${!color}$@${RESET}"; } # echo with specified color


###################
## Menu Function ##
###################
menu() {
  local ESC=$( printf "\033")
  cursor_blink_on()  { printf "$ESC[?25h"; }
  cursor_blink_off() { printf "$ESC[?25l"; }
  cursor_to()        { printf "$ESC[$1;${2:-1}H"; }
  print_option()     { printf "   $1 "; }
  print_selected()   { printf "  $ESC[7m $1 $ESC[27m"; }
  get_cursor_row()   { IFS=';' read -sdR -p $'\E[6n' ROW COL; echo ${ROW#*[}; }
  key_input()        { read -s -n3 key 2>/dev/null >&2
                       if [[ $key = "$ESC[A" ]]; then echo up;    fi
                       if [[ $key = "$ESC[B" ]]; then echo down;  fi
                       if [[ $key = ""     ]]; then echo enter; fi; }
  for opt; do printf "\n"; done
  local lastrow=$(get_cursor_row)
  local startrow=$(($lastrow - $#))
  trap "cursor_blink_on; stty echo; printf '\n'; exit" 2
  cursor_blink_off
  local selected=0
  while true; do
      printf "\n"
      local idx=0
      for opt; do
          cursor_to $(($startrow + $idx))
          if [ $idx -eq $selected ]; then
              print_selected "$opt"
          else
              print_option "$opt"
          fi
          ((idx++))
      done
      case $(key_input) in
          enter) break;;
          up)    ((selected--));
                 if [ $selected -lt 0 ]; then local selected=$(($# - 1)); fi;;
          down)  ((selected++));
                 if [ $selected -ge $# ]; then local selected=0; fi;;
      esac
  done
  cursor_to $lastrow
  printf "\n"
  cursor_blink_on
  return $selected; }


###############
## Functions ##
###############
receiverPower() {
  local inputURI='YamahaExtendedControl/v1/main/setInput?input=spotify'
  local powerURI='YamahaExtendedControl/v1/main/setPower?power=on'
  local inputEndpoint="http://${receiverIP}/${inputURI}"
  local powerEndpoint="http://${receiverIP}/${powerURI}"
  curl -s ${powerEndpoint} >/dev/null 2>&1; curl -s ${inputURI} >/dev/null 2>&1; }

spotifyToken() {
  [[ -z ${refreshToken} ]] && { _error "refresh_token not set."; exit 1; }
  if [[ -z ${access_token} ]];then
    local URL='https://accounts.spotify.com/api/token'
    local client_id='f252302e8fcd482c926b63358d6377f2'
    local client_secret='b6f24c7658544f9497b7948686e424ae'
    local grant_type='refresh_token'
    access_token=$(
    curl -s "${URL}" -X POST \
      -d "client_id=${client_id}&client_secret=${client_secret}&grant_type=${grant_type}&refresh_token=${refreshToken}"| jq .access_token)
    [[ -z ${access_token} ]] && { _error "Unable to get access token"; exit 1; }
  fi; }

spotifyDeviceID() {
  local URL='https://api.spotify.com/v1/me/player/devices'
  local deviceList=$(curl -s "${URL}" \
  -H "Authorization: Bearer ${access_token//\"/}" \
  -H "Content-Type: application/json"| jq .)
  local jqFilter="'.devices[]|select(.name == \"${deviceName}\")|.id'"
  deviceID=$(echo "${deviceList}"|eval jq ${jqFilter}|sed 's/"//g')
  [[ -z ${deviceID} ]] && { _error "Unable to get device ID."; exit 1; }; }

spotifyPlaybackInfo() { curl -s "${URL}" -H "Authorization: Bearer ${access_token//\"/}" -H "Content-Type: application/json"; }

spotifySetDevice() {
  local URL='https://api.spotify.com/v1/me/player'
  getCurrentDevice() { echo "$(spotifyPlaybackInfo)"|jq '.device.id'|sed 's/"//g';}
  getPlayState() { $(getInfo)|jq '.is_playing'; }
  until [[ $(getCurrentDevice) == ${deviceID} ]];do
    curl -s "${URL}" -X PUT \
      -d "{\"device_ids\":[\"${deviceID}\"]}" -H "Authorization: Bearer ${access_token//\"/}" -H "Content-Type: application/json"
      [[ $(getCurrentDevice) != ${deviceID} ]] && sleep 1
  done; }

spotifyResumePlayback() {
  local URL='https://api.spotify.com/v1/me/player'
  getPlayState() { echo "$(spotifyPlaybackInfo)"|jq '.is_playing'; }
  until [[ $(getPlayState) == true ]];do
    curl -s "${URL}" -X PUT -H "Authorization: Bearer ${access_token//\"/}"
    [[ $(getPlayState) != true ]] && sleep 1
  done; }

spotifyPlayContent() {
  local URL="https://api.spotify.com/v1/me/player/play?device_id=${deviceID}"
  curl -s "${URL}" -X PUT \
  -d "{\"context_uri\": \"${spotifyURI}\"}" \
  -H "Authorization: Bearer ${access_token//\"/}" \
  -H "Content-Type: application/json";}

spotifyShuffleContent() {
  local URL="https://api.spotify.com/v1/me/player/shuffle?state=true&device_id=${deviceID}"
  curl -s "${URL}" -X PUT \
  -H "Authorization: Bearer ${access_token//\"/}" \
  -H "Content-Type: application/json";}

spotifyRepeatContent() {
  local URL="https://api.spotify.com/v1/me/player/repeat?state=context&device_id=${deviceID}"
  curl -s "${URL}" -X PUT \
  -H "Authorization: Bearer ${access_token//\"/}" \
  -H "Content-Type: application/json";}

spotifySetVolume() {
  [[ -z ${volumeLevel} ]] && volumeLevel=50
  local URL="https://api.spotify.com/v1/me/player/volume?volume_percent=${volumeLevel}&device_id=${deviceID}"
  curl -s "${URL}" -X PUT \
  -H "Authorization: Bearer ${access_token//\"/}" \
  -H "Content-Type: application/json";}

spotifyControl() {
  spotifyToken
  #spotifySetDevice
  spotifyPlayContent
  spotifySetVolume
  spotifyShuffleContent
  spotifyRepeatContent; }


###################
## Help Function ##
###################
showHELP() {
  echo "${YELLOW}Options:${BLUE}"
  echo "    -h,--help                         Show this help menu."
  echo "    --yamaha                          Power on and change inputs of the receiver at the IP passed as an arg."
  echo "    --receiver-ip                     Specify an IP address to target when interacting with the yamaha receiver function."
  echo "    --set-device                      Set the current spotify device to the device name passed as an arg."
  echo "    --set-volume                      Set playback volumer percentage to the level passsed as an arg."
  echo "    --play-content                    Playback content at the URI passed as an arg."
  echo "    --shuffle-content                 Enable shuffle for playback."
  echo "    --repeate-content                 Enable repeat for playback."
  echo "    --device-name                     Pass target device name as arg."
  echo "    --resume-playback                 Resume spotify playback."
  echo
  echo "${YELLOW}Usage:${BLUE}"
  echo "    ./spotifyControl.sh"
  echo "    ./spotifyControl.sh [-h,--help]"
  echo "    ./spotifyControl.sh [--yamaha]"
  echo "    ./spotifyControl.sh [--receiver-ip][receiver IP]"
  echo "    ./spotifyControl.sh [--set-device][device name]"
  echo "    ./spotifyControl.sh [--set-volume][volume percent]"
  echo "    ./spotifyControl.sh [--play-content][content url]"
  echo "    ./spotifyControl.sh [--shuffle-content]"
  echo "    ./spotifyControl.sh [--repeat-content]"
  echo "    ./spotifyControl.sh [--device-name][device name]"
  echo "    ./spotifyControl.sh [--resume-playback]"
  echo "${RESET}"; exit 0; }


#######################
## Required Function ##
#######################
spotifyToken


##################
## Script Flags ##
##################
while test $# -gt 0;do
      case $1 in
              -h|--help)
                showHELP
                ;;
              --yamaha)
                receiverPower
                fullRun=false
                ;;
              --receiver-ip)
                shift
                receiverIP=${1}
                ;;
              --set-device)
                shift
                deviceName=${1}
                spotifyDeviceID
                spotifySetDevice
                fullRun=false
                ;;
              --play-content)
                shift
                spotifyURI="$(echo "${1}"|sed 's/.*\.com\//spotify:/g;s/\//:/g;s/\?.*//g')"
                spotifyPlayContent
                fullRun=false
                ;;
              --shuffle-content)
                spotifyShuffleContent
                fullRun=false
                ;;
              --repeat-content)
                spotifyRepeatContent
                fullRun=false
                ;;
              --set-volume)
                shift
                volumeLevel=${1}
                spotifySetVolume
                fullRun=false
                ;;
              --resume-playback)
                spotifyResumePlayback
                fullRun=false
                ;;
              --device-name)
                shift
                deviceName=${1}
                ;;
              *)
                _error "'$1' is not a valid argument."
                _info "A list of valid arguments can be found using -h or --help"
                exit 1
                ;;
      esac
      shift
done


[[ ${fullRun} != false ]] && spotifyControl
exit $?
