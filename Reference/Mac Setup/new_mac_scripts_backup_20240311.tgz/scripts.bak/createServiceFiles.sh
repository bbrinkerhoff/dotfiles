#!/bin/bash

saltRepoPath=/Users/bbrinkerhoff/repos/salt/new
saltMasters=(
  ut-prod-salt01
  hq-prod-salt01
  hq-stage-salt01
  hq-dev-salt01
  hq-sand-salt01.itsandbox.com)

createServiceFiles() {
  cd ${saltRepoPath}
  echo -n "current dir: "; pwd
  local icingaPillarPath="pillar/04_conf/icinga2/services"
  getMinions() {
    for master in ${saltMasters[@]};do
      ssh -qt ${master} 'sudo find /etc/salt/pki/master/minions -type f -printf "%f\n" | sed "s/ *//g" | sort | awk /./'
    done; }
  createIcinga() { 
    local service="$1"
    local serviceFile="${icingaPillarPath}/${service}.sls"
    local initFile="${icingaPillarPath}/init.sls"
    local initContent=$(sed '/^ *-/!d' ${initFile})
    if [[ ! -f ${serviceFile} ]];then
      echo "Creating icinga2 pillar for ${service}"
      local template="icinga2:
  services:
    %SERVICE%:
      hostgroups: []
      servicegroups: []
      checks: {}"
      sed -e "s;%SERVICE%;${service};g" -e "/^ *$/d" <<< "${template}" >> ${serviceFile}
      local newInitContent=$(echo "${initContent}"$'\n'"  - 04_conf.icinga2.services.${service}" | sort)
      echo "include:"$'\n'"${newInitContent}" > ${initFile}
    fi
  }
  local boxes=($(getMinions))
  local pillarPath="/Users/bbrinkerhoff/repos/salt/new"
  cd ${pillarPath}
  for box in ${boxes[@]};do
    local details=($(sed -E 's/([a-z]+)-([a-z]+)-(.*)([0-9]{2}).*/\1 \2 \3 \4/' <<< $box))
    local site=${details[0]}
    local env=${details[1]}
    local service=${details[2]}
    local number=${details[3]}

    local serviceStatePath="salt/service/${service}"
    local serviceStateInitPath="${serviceStatePath}/init.sls"
    local servicePillarPath="pillar/03_service/${site}/${env}/${service}"
    local serviceIcingaPath="pillar/04_conf/icinga2/services/${service}.sls"
    local initPath="${servicePillarPath}/init.sls"
    local nodePath="${servicePillarPath}/node${number}.sls"

    if ! [[ -d ${serviceStatePath} && -f ${serviceStateInitPath} && -d ${servicePillarPath} && -f ${initPath} && -f ${nodePath} ]];then
      echo
      echo "${box}"
      [[ ! -d ${serviceStatePath} ]] && { echo -n "  "; mkdir -v ${serviceStatePath}; }
      [[ ! -f ${serviceStateInitPath} ]] && { echo "  Creating file: ${serviceStateInitPath}"; touch ${serviceStateInitPath}; }
      [[ ! -d ${servicePillarPath} ]] && { echo -n "  "; mkdir -v ${servicePillarPath}; }
      [[ ! -f ${initPath} ]] && { echo "  Creating file: ${initPath}"; touch ${initPath}; }
      [[ ! -f ${nodePath} ]] && { echo "  Creating file: ${nodePath}"; touch ${nodePath}; }
      echo -e '\n\n'
    fi

    [[ ! -f ${serviceIcingaPath} ]] && createIcinga ${service}

  done
}

[[ -n $@ ]] && saltMasters=($@)
createServiceFiles
