testHTTP() { 
  local domains=(_domainconnect api beourguest bitbucket expressway hq-ewe-01 jira kings laguna launcher mail ns1 ns2 oku omega prm radar smtp smtp-timely-01 smtp-timely-02 smtp-timely-03 smtp-timely-04 smtp-timely-05 smtp-timely-1 smtp-timely-2 smtp-timely-3 synclauncher syncmanager ut-timely-04 ut-timely-05 vdi vnotify1 vnotify2 vpn ws1tunnel www)
  testCONNECT() { local method=$1; shift; local address=$1; curl -sqk --connect-timeout 2 ${method}://$address >/dev/null 2>&1; return $?; }
  testURL() { 
    local address=$1
    testCONNECT http ${address} && local http=TRUE
    testCONNECT https ${address} && local https=TRUE
    if [[ -n ${http} || -n ${https} ]];then
      local serverType=$(curl -sIq --connect-timeout 2 ${address} 2>/dev/null|sed '/Server/!d;s/.*: //g')
      echo "  ${address}:"
      [[ -n ${serverType} ]] && echo -e "    TYPE:  ${serverType}"
      [[ -n ${http} ]] && echo "    HTTP:  ${http}"
      [[ -n ${https} ]] && echo "    HTTPS: ${https}"
    fi; }
    testADDRESSES() {
      local url=${1}.communitect.com
      local IPS=($(host ${url} | sed '/has address/!d;s/.* //'))
      local results=$(
        for IP in ${IPS[@]};do
          testURL ${IP} &
        done; wait)
      if [[ -n ${results} ]];then
        echo "${url}:"
        echo "${results}"
      fi; }
  local services=$(
    for domain in ${domains[@]};do
      testADDRESSES ${domain} &
    done)
  echo "${services}"; }
