#!/bin/bash

# Written by Braydon Brinkerhoff to automate package version verification.
#################
## Global Vars ##
#################
GREEN=`tput -T xterm-256color setaf 2;tput -T xterm-256color bold`
RED=`tput -T xterm-256color setaf 1;tput -T xterm-256color bold`
YELLOW=`tput -T xterm-256color setaf 3;tput -T xterm-256color bold`
BLUE=`tput -T xterm-256color setaf 4;tput -T xterm-256color bold`
RESET=`tput -T xterm-256color sgr0;tput -T xterm-256color bold`
services=(srtomcat tomcat httpd srred5 srprweb amq srnotify sr_uber)
newServices=(apinotify convo convosockets enterprise patientreach payment reviews schedule schedulesync social strategicgoals support uber zipsms)
databases=(dbsrp dbcassandra dbnm)
g1_srtomcat=(
  "asterisk"
  "launcher.strategicgoals"
  "smtp.gateway"
  "webapp.api.crm"
  "webapp.conversations"
  "webapp.conversations_activity"
  "webapp.core"
  "webapp.ent"
  "webapp.launchers"
  "webapp.mrp"
  "webapp.msg"
  "webapp.payment"
  "webapp.redirect"
  "webapp.reviews"
  "webapp.schedule"
  "webapp.schedulesync"
  "webapp.social"
  "webapp.zipsms"
  "webapp.intake")
g1_srred5=("webapp.vid")
g1_httpd=("webapp.sup")
g1_sr_uber=("webapp.uber")
g2_tomcat=("webapp.pingserver" "webapp.syncmanager.tomcat" "webapp.syncmanager_launchers")
g3_amq=("activemq")
g3_srnotify=("webapp.api.notify")
g3_srprweb=("webapp.patientreach")
g3_srtomcat=("webapp.api.patientreach")
roles_dbsrp=("postgres.smilereminder.master" "db.smilereminder.master")
roles_dbcassandra=("cassandra.sr01.seed")
roles_dbnm=("db.numbermapping" "postgres.numbermapping")
g1_srtomcat_hosts=(); g1_tomcat_hosts=(); g1_httpd_hosts=(); g1_srred5_hosts=(); g1_srprweb_hosts=(); g1_amq_hosts=(); g1_srnotify_hosts=(); g1_sr_uber_hosts=()
g2_srtomcat_hosts=(); g2_tomcat_hosts=(); g2_httpd_hosts=(); g2_srred5_hosts=(); g2_srprweb_hosts=(); g2_amq_hosts=(); g2_srnotify_hosts=(); g2_sr_uber_hosts=()
g3_srtomcat_hosts=(); g3_tomcat_hosts=(); g3_httpd_hosts=(); g3_srred5_hosts=(); g3_srprweb_hosts=(); g3_amq_hosts=(); g3_srnotify_hosts=(); g3_sr_uber_hosts=()
dbsrp_hosts=(); dbcassandra_hosts=(); dbnm_host=()


##################
## Menu function #
##################
menu() {
  local ESC=$( printf "\033")
  cursor_blink_on()  { printf "$ESC[?25h"; }
  cursor_blink_off() { printf "$ESC[?25l"; }
  cursor_to()        { printf "$ESC[$1;${2:-1}H"; }
  print_option()     { printf "   $1 "; }
  print_selected()   { printf "  $ESC[7m $1 $ESC[27m"; }
  get_cursor_row()   { IFS=';' read -sdR -p $'\E[6n' ROW COL; echo ${ROW#*[}; }
  key_input()        { read -s -n3 key 2>/dev/null >&2
                       if [[ $key = "$ESC[A" ]]; then echo up;    fi
                       if [[ $key = "$ESC[B" ]]; then echo down;  fi
                       if [[ $key = ""     ]]; then echo enter; fi; }
  for opt; do printf "\n"; done
  local lastrow=`get_cursor_row`
  local startrow=$(($lastrow - $#))
  trap "cursor_blink_on; stty echo; printf '\n'; exit" 2
  cursor_blink_off
  local selected=0
  while true; do
      printf "\n"
      local idx=0
      for opt; do
          cursor_to $(($startrow + $idx))
          if [ $idx -eq $selected ]; then
              print_selected "$opt"
          else
              print_option "$opt"
          fi
          ((idx++))
      done
      case `key_input` in
          enter) break;;
          up)    ((selected--));
                 if [ $selected -lt 0 ]; then local selected=$(($# - 1)); fi;;
          down)  ((selected++));
                 if [ $selected -ge $# ]; then local selected=0; fi;;
      esac
  done
  cursor_to $lastrow
  printf "\n"
  cursor_blink_on
  return $selected; }


#############################
## Var Collection Function ##
#############################
setVARS() {
  joinBy() { local IFS=$1;shift;echo "$*"; }
  setENV() {
    until [[ -n $environment ]] && [[ -n $datacenter ]];do
      echo "What environment would you like to verify package versions in?"
      if menu "Staging (HQ)" "Production (UT)";then
        export environment=staging
        export datacenter=HQ
      else
        export environment=production
        export datacenter=UT
      fi
    done; }; setENV

  setHOSTS() {
    fmtNAMES() { sed '/dns/!d' <<< "$@"|cut -d, -f1|cut -d: -f2; }
    queryCMDB() {
      local auth="authorization: Basic Y29uZmx1ZW5jZToyVj1SR0pHXkt0KjgrVkZO"
      local query=`joinBy '|' $@`
      local params="?status!=decommissioned&datacenter=$datacenter&environment=$environment&role~($query)&dns!~(ping-03|ping-04)"
      fmtNAMES "`curl -q -s -H "$auth" -X GET https://cmdb.communitect.com/cmdb_api/v1.0/devices$params|sed '/\[\]/d'`"|sort; }
    if [[ -z "${hosts[@]}" ]];then
      echo "${YELLOW}Collecting host data for the $environment environment...${RESET}"
      for svc in "${services[@]}";do
        for group in 1 2 3;do
          local roles=g$group\_$svc[@]
          local array=g$group\_$svc\_hosts
          if [[ -n ${!roles} ]] && [[ -z ${!array} ]];then
            eval $array=\(`queryCMDB ${!roles}`\)
          fi
        done
      done; wait
      for db in "${databases[@]}";do
        local roles=roles_$db[@]
        local array=$db\_hosts
        if [[ -n ${!roles} ]] && [[ -z ${!array} ]];then
          eval $array=\(`queryCMDB ${!roles}`\)
        fi
      done
    fi; }; setHOSTS; }


###################################
## Package verification function ##
###################################
verifyPKGS() {
  echo "${YELLOW}Verifying installed packages...${RESET}"
  getPKGS() {
    fmtPKGS() { [[ -n $@ ]] && printf "    %-40s%-10s\n" `sed "s/ *@.*$//;s/ *installed$//;s/\.x86_64/:/" <<< "$@"`; [[ -z $@ ]] && printf "    %-40s%-10s\n" "No Packages" "N/A"; }
    echo -e "  ${RED}$1:\n${BLUE}$(fmtPKGS "`ssh -o "StrictHostKeyChecking=no" -q $1 'yum list installed $(yum list installed|grep -i -e '^sr-' -e '@sr-support')' 2>/dev/null|sed '/sr-/!d;/^@sr-support/d'`")${RESET}"; }
  for group in 1 2 3;do
    local hostPKGS=`
    for svc in "${services[@]}";do
      local array=g$group\_$svc\_hosts[@]
      if [[ -n ${!array} ]];then
        for host in ${!array};do
          getPKGS "$host" &
        done
      fi
    done
    wait`
    if [[ -n $hostPKGS ]];then echo "${GREEN}Group $group hosts:${RESET}"; echo "$hostPKGS";fi
  done; } 


######################
## Key add function ##
######################
addKEY() {
  setENV
  setVARS
  for group in 1 2 3;do
    for svc in "${services[@]}";do
      local array=g$group\_$svc\_hosts[@]
      if [[ -n ${!array} ]];then
        for host in ${!array};do
          ssh-copy-id -o "StrictHostKeyChecking=no" $host
        done
      fi
    done
  done; }


########################
## Quick env function ##
########################
setENV() {
  local env=$1
  shopt -s nocasematch
  if [[ $env =~ ^(stg|stage|staging)$ ]];then
    environment=staging
    datacenter=HQ
  elif [[ $env =~ ^(prd|prod|production)$ ]];then
    environment=production
    datacenter=UT
  fi; shopt -u nocasematch; }


###################
## Help Function ##
###################
showHELP() {
  echo "${YELLOW}Options:${BLUE}"
  echo "    -h,--help                         Show this help menu."
  echo "    -k,--key                          Add your local ssh key to every host in chosen environment."
  echo
  echo "${YELLOW}Usage:${BLUE}"
  echo "    ./verifyPKGS.sh"
  echo "    ./verifyPKGS.sh [staging|production]"
  echo "    ./verifyPKGS.sh [-k,--key] [staging|production]"
  echo "${RESET}"; exit 0; }


#################
## Script Flags #
#################
while test $# -gt 0; do
      case "$1" in
              -h|--help)
                    showHELP
                    exit 0
                    ;;
              -k|--key)
                    addKEY
                    exit 0
                    ;;
              -*)
                    echo "${RED}'$1' is not a valid parameter.${RESET}"
                    exit 0
                    ;;
              *)
                    setENV "$1"
                    shift
                    ;;
      esac
done


#########################
# Run default functions #
#########################
setENV "$1"
setVARS
verifyPKGS
exit 0
