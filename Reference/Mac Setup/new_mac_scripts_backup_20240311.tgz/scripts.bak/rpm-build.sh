#!/bin/bash

DOTNETBIN="${DOTNETBIN:-/usr/share/dotnet/dotnet}"
BUILDCONFIG="${BUILDCONFIG:-Release}"
FPMBIN="${FPMBIN:-/usr/local/bin/fpm}"

_COLORS=${BS_COLORS:-$(tput colors 2>/dev/null || echo 0)}
__detect_color_support() {
    if [ $? -eq 0 ] && [ "$_COLORS" -gt 2 ]; then
        RC="\033[1;31m"
        GC="\033[1;32m"
        BC="\033[1;34m"
        YC="\033[1;33m"
        EC="\033[0m"
    else
        RC=""
        GC=""
        BC=""
        YC=""
        EC=""
    fi
}
__detect_color_support

echoerror() {
    printf "${RC} * ERROR${EC}: %s\n" "$@" 1>&2;
}

echoinfo () {
    printf "${GC} *  INFO${EC}: %s\n" "$@";
}

_git_pull () {
    echoinfo "ENSURING CODE IS UP TO DATE...."
    [[ -n $branch ]] && git checkout $branch
    git pull --recurse-submodules --rebase
    git submodule update --init --recursive
}

_cleanup_old_builds () {
    echoinfo "CLEANING UP ANY OLD BUILDS...."
    rm -rfv Solutionreach.SyncManager/bin/{Release,Debug}/netcoreapp2.{1,2}/publish
    rm -v ./*.rpm
}

_compile_dotnet () {
    
    echoinfo "COMPILING NATIVE LINUX SQLITE LIBRARY...."
    (cd sync-import/sync-export/sync-sqlite/native/ && sh ./compile.linux.sh)
    echoinfo "COMPILING MANAGER...."
    (cd Solutionreach.SyncManager/ && ${DOTNETBIN} publish -c ${BUILDCONFIG} -f netcoreapp2.2 -m:1)
}

_build_rpms () {
    echoinfo "BUILDING PACKAGES"
    MANAGER_VERSION=$(cat Solutionreach.SyncManager/Solutionreach.SyncManager.csproj | xq -r '.Project | .PropertyGroup | .AssemblyVersion')
    echoinfo "BUILDING MANAGER RPM WITH VERSION ${MANAGER_VERSION}...."
    ${FPMBIN} -t rpm -s dir --force -n sr-syncmanager -v ${MANAGER_VERSION} \
        --provides sr-syncmanager -m 'ops@solutionreach.com' --url 'SyncManager' \
        --vendor 'SR' --rpm-summary 'SR SyncManager' --prefix /opt/syncmanager/ \
        -C Solutionreach.SyncManager/bin/${BUILDCONFIG}/netcoreapp2.2/publish
}

_chown_bamboo () {
    chown -R bamboo:bamboo ./*
}

[[ $# -eq 0 ]] && echoerror "Usage: $ build.sh [gitpull|compile|build-rpms|clean|full]" && exit 1

while test $# -gt 0; do
    case $1 in 
        gitpull)
          shift
          branch=$1
          _git_pull
          shift
          ;;
        compile)
          _compile_dotnet
          shift
          ;;
        build-rpms)
          _build_rpms
          shift
          ;;
        clean)
          _cleanup_old_builds
          shift
          ;;
        full)
          _cleanup_old_builds ; \
          _compile_dotnet && \
          _build_rpms
          shift
          ;;
        bamboofull)
          _cleanup_old_builds ; \
          _compile_dotnet && \
          _build_rpms && \
          _chown_bamboo
          shift
          ;;
        *)
          echoerror "Usage: $ build.sh [gitpull|compile|build-rpms|clean|full]"
          exit
          ;;
    esac
done
