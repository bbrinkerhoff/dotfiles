#!/bin/bash

#integrations_salt_deploy_script.sh - only has execute permissions for the bamboo agent. 
#execute-only permissions - no read/write without root access.
#shared between all bamboo agents

# Path to a file that contains one or more variables
# Note: If this file is going to contain values for the 'PASSWORD' variable, it should be set to no more than '0640' permissions ('0600' 'root:root' preferred).
# Note: This file should be in the format of:
# VAR=VALUE
# VAR2=VALUE2
envFile=/path/to/file
colorizedOutput=True # Enable or disable colorized output. -- Disabled by default.

# Set variables to enable colorized output
enableColors() {
  GREEN=`tput -T xterm-256color setaf 2;tput -T xterm-256color bold`
  RED=`tput -T xterm-256color setaf 1;tput -T xterm-256color bold`
  RESET=`tput -T xterm-256color sgr0;tput -T xterm-256color bold`
}

# Read vars from env file but always exclude the SERVICE and ENVIRONMENT variables even if set
readVars() {
  local filePath="$1"
  local tmpFile=$(mktemp /tmp/sync-deploy.envfile.tmp.XXX)
  if [[ -f $filePath ]];then
    sed '/SERVICE=/d;/ENVIRONMENT=/d' $filePath > $tmpFile
    echoinfo "Reading variables from env file: $filePath"
    [[ -f $tmpFile ]] && . $tmpFile && rm -f $tmpFile
  else
    echoerror "Cannot find or read file at path: $envFile"
  fi
}

# Echo text to stderr
echoerror() {
    printf "${RED} * ERROR${RESET}: %s\n" "$@" 1>&2;
}

# Echo text to stdout
echoinfo() {
    printf "${GREEN} *  INFO${RESET}: %s\n" "$@";
}

# Run salt deployment
deploySalt() {
  # Set local function variables
  local tmpFile=$(mktemp /tmp/sync-deploy.tmp.XXX)
  local saltMaster="$envPrefix-salt01.communitect.com"
  local saltService="$envPrefix-$SERVICE"

  echoinfo "Starting deployment to salt..."

  # Authenticate with the appropriate Salt Master and output the authetication cookie to a temp file
  local IFS=$'\n'; local authOutput=(`
    curl -sSk https://$saltMaster:8000/login \
    -c $tmpFile \
    -H 'Accept: application/x-yaml' \
    -d username=$USERNAME \
    -d password=$PASSWORD \
    -d eauth=pam`)
  if [[ $? -eq 0 ]];then 
    echoinfo "Successfully authenticated with the Salt Master: $saltMaster"
    echoinfo "Authentication output:" ${authOutput[@]}
  else
    echoerror "Failed to authenticate with the Salt Master: $saltMaster"
    exit 1
  fi

  # Request highstate for the minions matching <site>-<env>-<service>*
  local saltOutput=(`curl -sSk https://$saltMaster:8000/ \
      -b $tmpFile \
      -H 'Accept: application/json' \
      -d client=local \
      -d tgt="$saltService*" \
      -d fun=state.sls \
      -d arg=service.$SERVICE`)
  if [[ $? -eq 0 ]];then
    local prettyPrint=(`jq . <<< "$saltOutput"`)
    echoinfo "Successfully posted state.sls service.$SERVICE for the '$saltService' service on the Salt Master: '$saltMaster'."
    echoinfo "Response from Salt Master:" ${prettyPrint[@]}
  else
    echoerror "Failed to post highstate request for the '$saltService' service on the Salt Master: '$saltMaster'."
    exit 1
  fi

  echoinfo "$(rm -vf $tmpFile)"
}

# Parse through script flags and set variables from arguments
while test $# -gt 0;do
    case "$1" in
        -u|--user)
            shift
            USERNAME=$1
            shift
            ;;
        -p|--password)
            shift
            PASSWORD=$1
            shift
            ;;
        -e|--environment)
            shift
            ENVIRONMENT=$1
            shift
            ;;
        -s|--service)
            shift
            SERVICE=$1
            shift
            ;;
        -f|--file)
            shift
            envFile=$1
            shift
            ;;
        -c|--color)
            enableColors
            shift
            ;;
        -*|*)
            echoerror "'$1' is not a valid flag."
            echoerror "Accepted flags include:" \
            "[-u,--user] [username]" \
            "[-p,--password] [password]"\
            "[-e,--environment] [environment]" \
            "[-s,--service] [service]" \
            "[-f,--file] [filepath]"
            exit 1
            ;;
    esac
done

# Enable colorized output if set
[[ $colorizedOutput == True ]] && enableColors

# Ingest variables from an environment file if file exists
[[ -f $envFile ]] && readVars "$envFile"

# Error out if every variable is not defined
[[ -z $USERNAME || -z $PASSWORD || -z $ENVIRONMENT || -z $SERVICE ]] && \
echoerror "One or more arguments were empty." "Arguments are: USERNAME, PASSWORD, ENVIRONMENT, SERVICE." && exit 1

# Set prefix based off of environment
case $ENVIRONMENT in
    dev|development)
        envPrefix='hq-dev'
        ;;
    stg|stage|staging)
        envPrefix='hq-stage'
        ;;
    prd|prod|production)
        envPrefix='ut-prod'
        ;;
    *)
        echoerror "'$ENVIRONMENT' is not a valid environment value."
        exit 1
        ;;
esac

# Hello World
echoinfo "HELLO WORLD"
echoerror "HELLO WORLD"

# Run deployment function assuming all tests above return true
deploySalt
