serverTEST() {
  servers=($@)
  local responsive=()
  local unresponsive=()
  local undefined=()

  for server in ${servers[@]};do
    ping -c 1 -W 3 ${server} >/dev/null 2>&1; local out=$?
    if [[ ${out} == 0 ]];then
      responsive+=(${server})
    elif [[ ${out} == 2 ]];then
      unresponsive+=(${server})
    elif [[ ${out} == 68 ]];then
      undefined+=(${server})
    fi
  done
  local IFS=$'\n'
  echo "${GREEN}RESPONSIVE:${RESET}"
  echo "${responsive[*]/#/  - }"
  echo
  echo "${RED}UNRESPONSIVE:${RESET}"
  echo "${unresponsive[*]/#/  - }"
  echo
  echo "${YELLOW}UNDEFINED:${RESET}"
  echo "${undefined[*]/#/  - }"
}
