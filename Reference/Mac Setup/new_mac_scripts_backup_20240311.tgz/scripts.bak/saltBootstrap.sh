sudo rpm --import https://repo.saltproject.io/py3/redhat/7/x86_64/archive/3002.2/SALTSTACK-GPG-KEY.pub; \
curl -fsSL https://repo.saltproject.io/py3/redhat/7/x86_64/archive/3000.2.repo | sudo tee /etc/yum.repos.d/saltstack.repo; \
yum install salt-minion -y


saltBootstrap() {
  # Import Salt GPG pub key
  sudo rpm --import https://repo.saltproject.io/py3/redhat/7/x86_64/archive/3002.2/SALTSTACK-GPG-KEY.pub
  # Curl Salt 3002.2 repo and put in file /etc/yum.repos.d/saltstack.repo
  curl -fsSL https://repo.saltproject.io/py3/redhat/7/x86_64/archive/3000.2.repo | sudo tee /etc/yum.repos.d/saltstack.repo
  # Install the salt-minion package
  yum install salt-minion -y

  # Set Salt Master address (Will be prompted for it if not set, just saves time)
  local saltMaster="kc-prod-salt01"
  # If ${saltMaster} variable is not set, prompt user to enter it
  while [[ -z ${saltMaster} ]];do
    # Read input, set input to saltMaster var
    read -ep "Salt Master: " saltMaster
  done

  # Set minionID variable if not set
  while [[ -z ${minionID} ]];do
    # Read input, set input to minionID
    read -ep "Minion ID: " minionID
  done
  # Salt Minion config template - Variables filled later
  local minionConfig="id: %MINIONID%
master:
  - %SALTMASTER%
master_alive_interval: 30
retry_dns: 30
hash_type: sha256

use_superseded:
  - module.run"

  echo "Generating / Populating Salt minion config"
  # Replace %% variables in config template and replace config in /etc/salt/minion
  sed -e "s;%SALTMASTER%;${saltMaster};g" -e "s;%MINIONID%;${minionID};g" <<< "${minionConfig}" | tee /etc/salt/minion


  echo -e "\n\nRestarting Salt Minion service\n"
  # Restart salt-minion service (minion key should show up on the Salt Master)
  sudo systemctl restart salt-minion

  echo -e "\n\nEnabling Salt Minion service\n"
  # Enable salt-minion service so it starts on boot
  sudo systemctl enable salt-minion
}
