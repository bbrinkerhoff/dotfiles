#!/bin/bash

#################
## Global Vars ##
#################
GREEN=`tput -T xterm-256color setaf 2;tput -T xterm-256color bold`
RED=`tput -T xterm-256color setaf 1;tput -T xterm-256color bold`
YELLOW=`tput -T xterm-256color setaf 3;tput -T xterm-256color bold`
BLUE=`tput -T xterm-256color setaf 4;tput -T xterm-256color bold`
RESET=`tput -T xterm-256color sgr0;tput -T xterm-256color bold`
hostgroups=(); servicegroups=(); groups=(); site=; env=; service=;

###################
## Menu Function ##
###################
menu() {
  local ESC=$( printf "\033")
  cursor_blink_on()  { printf "$ESC[?25h"; }
  cursor_blink_off() { printf "$ESC[?25l"; }
  cursor_to()        { printf "$ESC[$1;${2:-1}H"; }
  print_option()     { printf "   $1 "; }
  print_selected()   { printf "  $ESC[7m $1 $ESC[27m"; }
  get_cursor_row()   { IFS=';' read -sdR -p $'\E[6n' ROW COL; echo ${ROW#*[}; }
  key_input()        { read -s -n3 key 2>/dev/null >&2
                       if [[ $key = "$ESC[A" ]]; then echo up;    fi
                       if [[ $key = "$ESC[B" ]]; then echo down;  fi
                       if [[ $key = ""     ]]; then echo enter; fi; }
  for opt; do printf "\n"; done
  local lastrow=`get_cursor_row`
  local startrow=$(($lastrow - $#))
  trap "cursor_blink_on; stty echo; printf '\n'; exit" 2
  cursor_blink_off
  local selected=0
  while true; do
      printf "\n"
      local idx=0
      for opt; do
          cursor_to $(($startrow + $idx))
          if [ $idx -eq $selected ]; then
              print_selected "$opt"
          else
              print_option "$opt"
          fi
          ((idx++))
      done
      case `key_input` in
          enter) break;;
          up)    ((selected--));
                 if [ $selected -lt 0 ]; then local selected=$(($# - 1)); fi;;
          down)  ((selected++));
                 if [ $selected -ge $# ]; then local selected=0; fi;;
      esac
  done
  cursor_to $lastrow
  printf "\n"
  cursor_blink_on
  return $selected; }


#############################
## Var Collection Function ##
#############################
getVARS() {
  getHOSTGROUPS() {
    getGROUPS()  {
      unset groups
      while read -e group;do
        [[ -z "$group" ]] && break;
        groups+=("$group")
      done
      echo "${groups[@]}"; }
    echo "${BLUE}Would you like to set any hostgroups?${RESET}"
    if menu yes no;then
      echo "${YELLOW}Please enter the name of each group you would like to add on a new line. When you are done, hit enter on an empty new line.${RESET}"
      hostgroups=(`getGROUPS`)
    fi
    echo "${BLUE}Would you like to set any servicegroups?${RESET}"
    if menu yes no;then
      echo "${YELLOW}Would you like to set the service groups to be the same as the host groups?${RESET}"
      if menu yes no;then
        servicegroups=(${hostgroups[@]})
      else
        echo "${YELLOW}Please enter the name of each group you would like to add on a new line. When you are done, hit enter on an empty new line.${RESET}"
        servicegroups=(`getGROUPS`)
      fi
    fi; }
  getSITE() {
    local sites=(hq usctr ut)
    local envs=(prod stage)
    echo "${BLUE}Which site would you like to create this service in?${RESET}"
    menu ${sites[@]}; site=${sites[$?]}
    echo "${BLUE}Which env would you like to create this service in?${RESET}"
    menu ${envs[@]}; env=${envs[$?]}; }
  getSERVICE() {
    echo "${BLUE}What is the name of the service you want to create?${RESET}"
    read -e service; }
  getSERVICE
  getSITE
  getHOSTGROUPS; }



###############################
## Service Creation Function ##
###############################
makeSERVICE() {
  makePILLAR() {
    makeTEMPLATE() {
      echo "icinga2:"
      echo "  services:"
      echo "    $service:"
      if [[ -n $hostgroups ]];then
        echo "      hostgroups:"
        for group in ${hostgroups[@]};do
          echo "        - $group"
        done
      fi
      if [[ -n $servicegroups ]];then
        echo "      servicegroups:"
        for group in ${servicegroups[@]};do
          echo "        - $group"
        done
      fi
      echo "      checks: {}"
      echo; }
    local pillarSLS=`makeTEMPLATE`
    echo -n "$pillarSLS" > ./pillar/04_conf/icinga2/services/$service.sls
    local serviceIncludes=`sed '/include\:/d' ./pillar/04_conf/icinga2/services/init.sls`
    local serviceIncludes+=$'\n'"  - 04_conf.icinga2.services.$service"
    local serviceIncludes=`echo "$serviceIncludes"|sort -u`
    echo "include:" > ./pillar/04_conf/icinga2/services/init.sls
    echo "$serviceIncludes" >> ./pillar/04_conf/icinga2/services/init.sls
    mkdir ./pillar/03_service/$site/$env/$service 2>/dev/null
    touch ./pillar/03_service/$site/$env/$service/{init,node01}.sls; }
  makeSERVICEDIRS() {
    mkdir salt/service/$service 2>/dev/null
    touch salt/service/$service/init.sls; }
  addVAR() {
    local winSvc=`sed '/-/!d' ./salt/modules/icinga2/defaults.yaml`
    local winSvc+=$'\n'"    - $service"
    local winSvc=`echo "$winSvc"|sort -u`
    echo "icinga2:" > ./salt/modules/icinga2/defaults.yaml
    echo "  version: '2.10.4'" >> ./salt/modules/icinga2/defaults.yaml
    echo "  Windows_services:" >> ./salt/modules/icinga2/defaults.yaml
    echo "$winSvc" >> ./salt/modules/icinga2/defaults.yaml; }
  makePILLAR
  makeSERVICEDIRS
  echo "${YELLOW}Is this a Windows service?${RESET}"
  if menu yes no;then
    addVAR
  fi; }



getVARS
makeSERVICE
