#!/bin/bash

##############
## App Vars ##
##############
APP='sync-endpoint'; service='syncprocessor'
prodServers=(
  ut-prod-sync-endpoint01
  ut-prod-sync-endpoint02
  ut-prod-sync-endpoint03
  ut-prod-sync-endpoint04
  ut-prod-sync-endpoint05
  ut-prod-sync-endpoint06
  ut-prod-sync-endpoint07
  ut-prod-sync-endpoint08
  ut-prod-sync-endpoint09
)
stageServers=(
  hq-stage-sync-endpoint01
  hq-stage-sync-endpoint02
)
bothServers=(
  ${stageServers[@]}
  ${prodServers[@]}
)

#################
## Global Vars ##
#################
environment=; servers=()


################
## Color Vars ##
################
GREEN=`tput -T xterm-256color setaf 2;tput -T xterm-256color bold`
RED=`tput -T xterm-256color setaf 1;tput -T xterm-256color bold`
YELLOW=`tput -T xterm-256color setaf 3;tput -T xterm-256color bold`
BLUE=`tput -T xterm-256color setaf 4;tput -T xterm-256color bold`
RESET=`tput -T xterm-256color sgr0;tput -T xterm-256color bold`


##################
## Menu function #
##################
menu() {
  local ESC=$( printf "\033")
  cursor_blink_on()  { printf "$ESC[?25h"; }
  cursor_blink_off() { printf "$ESC[?25l"; }
  cursor_to()        { printf "$ESC[$1;${2:-1}H"; }
  print_option()     { printf "   $1 "; }
  print_selected()   { printf "  $ESC[7m $1 $ESC[27m"; }
  get_cursor_row()   { IFS=';' read -sdR -p $'\E[6n' ROW COL; echo ${ROW#*[}; }
  key_input()        { read -s -n3 key 2>/dev/null >&2
                       if [[ $key = "$ESC[A" ]]; then echo up;    fi
                       if [[ $key = "$ESC[B" ]]; then echo down;  fi
                       if [[ $key = ""     ]]; then echo enter; fi; }
  for opt; do printf "\n"; done
  local lastrow=`get_cursor_row`
  local startrow=$(($lastrow - $#))
  trap "cursor_blink_on; stty echo; printf '\n'; exit" 2
  cursor_blink_off
  local selected=0
  while true; do
      printf "\n"
      local idx=0
      for opt; do
          cursor_to $(($startrow + $idx))
          if [ $idx -eq $selected ]; then
              print_selected "$opt"
          else
              print_option "$opt"
          fi
          ((idx++))
      done
      case `key_input` in
          enter) break;;
          up)    ((selected--));
                 if [ $selected -lt 0 ]; then local selected=$(($# - 1)); fi;;
          down)  ((selected++));
                 if [ $selected -ge $# ]; then local selected=0; fi;;
      esac
  done
  cursor_to $lastrow
  printf "\n"
  cursor_blink_on
  return $selected; }


##################
## Var function ##
##################
setVARS() {
  local envs=(stage prod both)
  if [[ -z $environment ]];then
    echo "${BLUE}Which environment do you want to target?${RESET}"
    menu ${envs[@]}; environment=${envs[$?]}
  fi
  serverVar="${environment}Servers[@]"
  servers=(${!serverVar})

  echo "${BLUE}Servers being targeted:"
  for server in "${servers[@]}";do
    echo "  $server"
  done
  echo "${RESET}"
}

setENV() {
  local env=$1
  shopt -s nocasematch
  if [[ $env =~ ^(stg|stage|staging)$ ]];then
    environment=stage
  elif [[ $env =~ ^(prd|prod|production)$ ]];then
    environment=prod
  elif [[ $env =~ ^(both|stage prod|prod stage)$ ]];then
    environment=both 
  fi; shopt -u nocasematch
}


#######################
## Package functions ##
#######################
buildRPM() {
  echo "${GREEN}Updating ${APP} repository...${RESET}"
  (cd ${HOME}/build/${APP}/ && sh rpm-build.sh gitpull)
  echo "${BLUE}Starting RPM build for ${APP}...${RESET}"
  rm -fv ${HOME}/build/${APP}/sr-sync*.rpm 2>/dev/null
  docker run -ti --volume ${HOME}/build/${APP}/:/opt/${APP//-/} --workdir /opt/${APP//-/}/ --rm docker.communitect.com/sreach/dotnet31 /bin/bash -c '/bin/bash ./rpm-build.sh'
}

scpRPM() {
  echo "${BLUE}Copying ${APP} rpm over scp to corresponding servers...${RESET}"
  for server in "${servers[@]}";do
    { if ( scp -q ${HOME}/build/${APP}/sr-sync*.rpm $server:~/ >/dev/null 2>&1 );then \
        echo "${BLUE}  $server: ${GREEN}Success${RESET}"; \
      else echo "${BLUE}  $server: ${RED}Fail${RESET}"; \
      fi; \
    } &
  done|sort|awk '/./'; wait
}

deployRPM() {
  echo "${BLUE}Deploying RPM to servers in ${environment} environment...${RESET}"
  for server in "${servers[@]}";do
    echo "${GREEN}Deploying rpm to $server...${RESET}"
    ssh -qt $server "sudo systemctl stop $service; sudo yum localinstall ~/sr-sync*.rpm -y; sudo systemctl start $service"
  done
}

sshCOPYID() {
  echo "${BLUE}Copying ssh public key to ${APP} servers...${RESET}"
  for server in "${servers[@]}";do
    ssh-copy-id $server
  done
}

_done() { echo -e "${GREEN}\nDone!\n${RESET}"; exit 0; }


###################
## Help Function ##
###################
showHELP() {
  echo "${YELLOW}Options:${BLUE}"
  echo "    -h,--help                         Show this help menu."
  echo "    -b,--build                        Build the latest version of the ${APP} RPM."
  echo "    -s,--scp                          SCP the last built RPM file to ${APP} servers."
  echo "    -d,--deploy                       Install the latest RPM on ${APP} servers."
  echo "       --no-deploy                    Run every function except the final deployment."
  echo "       --ssh-id                       Copy SSH Public Key to ${APP} servers."
  echo "${RESET}"; }


##################
## Script flags ##
##################
while test $# -gt 0;do
  case "$1" in
      -h|--help)
        showHELP
        exit 0
        ;;
      -b|--build)
        shift
        setENV "$1"
        buildRPM
        exit 0
        ;;
      -s|--scp)
        shift
        setENV "$1"
        setVARS
        scpRPM
        exit 0
        ;;
      -d|--deploy)
        shift
        setENV "$1"
        setVARS
        deployRPM
        exit 0
        ;;
      --no-deploy)
        shift
        deployRPM() { echo "${YELLOW}Skipping deploy...${RESET}"; }
        ;;
      --ssh-id)
        shift
        setENV "$1"
        setVARS
        sshCOPYID
        exit 0
        ;;
      -*)
        echo "${RED}'$1' is not a valid argument.${RESET}"
        exit 1
        ;;
      *)
        setENV "$1"
        shift
        ;;
  esac
done

setVARS
buildRPM
scpRPM
deployRPM
_done
