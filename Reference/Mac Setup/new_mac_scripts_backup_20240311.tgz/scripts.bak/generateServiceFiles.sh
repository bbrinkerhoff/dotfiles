#!/bin/bash

[[ -n $@ ]] && saltMasters=($@)
joinBY() { local IFS="${1}"; shift; echo "$*"; }

saltRepoPath=~/repos/salt/new IFS=$'\n'
icingaPillarPath="${saltRepoPath}/pillar/04_conf/icinga2/services"
pillarServiceDir="${saltRepoPath}/pillar/03_service"
saltServiceDir="${saltRepoPath}/salt/service"
minionPath="/etc/salt/pki/master/minions"
yamlPath="${saltRepoPath}/salt/modules/icinga2/defaults.yaml"
excludedServices=(adavis  aterry  brichins  wndoh)
excludeString=$(joinBY '|' "${excludedServices[@]}")
saltMasters=(ut-prod-salt01  hq-prod-salt01  hq-stage-salt01  hq-dev-salt01)
minions=($(for master in "${saltMasters[@]}";do ssh -q ${master} "sudo find ${minionPath} -maxdepth 1 -type f -printf '%f\n'";done|sort))
services=($(echo "${minions[*]}"|perl -pe 's/^(\w+-){2}(.*)\d{2}/$2/g'|sort -u))
icingaServices=(${services[*]} $(find ${icingaPillarPath} -depth 1 -type f|perl -pe 's/^.*\/(.*)\.sls$/$1/g'))
icingaServices=($(echo "${icingaServices[*]}"|sort -u))


makeServiceFiles()
{
  echo "Creating pillar files and directories for present services..."
  # Create pillar directories and files for services corresponding with ${minions[*]}
  pillarNodeFiles=($(echo "${minions[*]}"|perl -pe "s|^(\w+)-(\w+)-(.*)(\d{2})$|${pillarServiceDir}/\$1/\$2/\$3/node\$4.sls|g"))
  pillarServiceDirs=($(echo "${pillarNodeFiles[*]%/*}"|sort -u))
  for dir in "${pillarServiceDirs[@]}";do mkdir -pv "${dir}"; touch "${dir}/init.sls"; done
  touch ${pillarNodeFiles[@]}
  
  echo "Creating salt files and directories for present services..."
  # Create salt directories and files for services corresponding with ${minions[*]}
  saltServiceDirs=($(echo "${minions[*]}" | perl -pe "s|^(\w+-){2}(.*)\d{2}$|${saltServiceDir}/\$2|g"|sort -u))
  for dir in "${saltServiceDirs[@]}";do mkdir -pv "${dir}"; touch "${dir}/init.sls"; done
}


makeIcingaServiceFiles()
{
  echo "Creating Icinga2 service files..."
  for svc in "${services[@]}";do
    if [[ ! -f "${icingaPillarPath}/${svc}.sls" ]]
    then
      echo "Creating Icinga2 pillar SLS for ${svc}..."
      local template="icinga2:
  services:
    %SERVICE%:
      hostgroups: []
      servicegroups: []
      checks: {}"
        sed -e "s;%SERVICE%;${service};g" -e "/^ *$/d" <<< "${template}" >> "${icingaPillarPath}/${svc}.sls"
      fi
    done

    echo "Recreating Icinga2 service 'init.sls' with found services..."
    includeString="  - 04_conf.icinga2.services."
    serviceIncludes=($(echo "${icingaServices[*]}"|sed -E "/^(${excludeString}|init)$/d;s/^/${includeString}/g"))
    initContents="include:"$'\n'"${serviceIncludes[*]}"
    echo "${initContents}" > "${icingaPillarPath}/init.sls"
}


winServicesListUpdate()
{
  echo "Updating 'Windows_services' key in the icinga2 module's 'default.yaml'..."
  winMinions=($(for master in "${saltMasters[@]}";do ssh -q "${master}" \
                "sudo salt -G kernel:Windows test.ping --timeout=5 2>/dev/null|grep True -B1|perl -pe 's/( *True.*\n?|:)$//g'"
              done))
  winServices=($(echo "${winMinions[*]}" | perl -pe 's/^(\w+-){2}(.*)\d{2}$/$2/g'))
  winServices+=($(yq '.icinga2.Windows_services[]' ${yamlPath}))
  winServices=($(echo "${winServices[*]}" | sort -u ))
  winServiceList=$(joinBY ', ' $(for x in ${winServices[@]};do echo "\"${x}\"";done))
  yq -i ".icinga2.Windows_services = [ ${winServiceList} ]" "${yamlPath}"
}


# Run shit
makeServiceFiles
makeIcingaServiceFiles
winServicesListUpdate
echo "Finished creating files."