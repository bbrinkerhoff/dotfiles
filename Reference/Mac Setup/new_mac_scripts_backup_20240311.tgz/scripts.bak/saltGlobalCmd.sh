#!/bin/bash

menu() {
  local ESC=$( printf "\033")
  cursor_blink_on()  { printf "$ESC[?25h"; }
  cursor_blink_off() { printf "$ESC[?25l"; }
  cursor_to()        { printf "$ESC[$1;${2:-1}H"; }
  print_option()     { printf "   $1 "; }
  print_selected()   { printf "  $ESC[7m $1 $ESC[27m"; }
  get_cursor_row()   { IFS=';' read -sdR -p $'\E[6n' ROW COL; echo ${ROW#*[}; }
  key_input()        { read -s -n3 key 2>/dev/null >&2
                       if [[ $key = "$ESC[A" ]]; then echo up;    fi
                       if [[ $key = "$ESC[B" ]]; then echo down;  fi
                       if [[ $key = ""     ]]; then echo enter; fi; }
  for opt; do printf "\n"; done
  local lastrow=`get_cursor_row`
  local startrow=$(($lastrow - $#))
  cursor_blink_off
  local selected=0
  while true; do
      printf "\n"
      local idx=0
      for opt; do
          cursor_to $(($startrow + $idx))
          if [ $idx -eq $selected ]; then
              print_selected "$opt"
          else
              print_option "$opt"
          fi
          ((idx++))
      done
      case `key_input` in
          enter) break;;
          up)    ((selected--));
                 if [ $selected -lt 0 ]; then local selected=$(($# - 1)); fi;;
          down)  ((selected++));
                 if [ $selected -ge $# ]; then local selected=0; fi;;
      esac
  done
  cursor_to $lastrow
  printf "\n"
  cursor_blink_on
  return $selected; }

sendCMD() {
  local masters=(
    hq-sand-salt01.itsandbox.com
    hq-dev-salt01
    hq-stage-salt01
    hq-prod-salt01
    ut-prod-salt01
    10.112.8.3 # usctr-prod-salt01
    #kc-prod-salt01
  )

  local cmd="$@"

  if [[ -n ${cmd} ]];then
    echo "Send this command?"
    echo "${YELLOW}  ${cmd}${RESET}"
    if ! menu no yes;then
      echo "Sending command to all salt masters"; echo
      for master in ${masters[@]};do
        echo "Sending command to ${master}"
        ssh -q -t ${master} "sudo ${cmd}"
      done
    fi
  else
    echo "No cmd supplied."
  fi
}

sendCMD "$@"
