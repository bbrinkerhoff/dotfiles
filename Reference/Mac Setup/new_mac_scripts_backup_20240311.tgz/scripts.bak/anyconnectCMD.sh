anyconnectCMD() {
  local cmd="/opt/cisco/anyconnect/bin/vpn -s" cmdType=${1:?No VPN command provided\!}; shift

  status() { printf "state" | ${cmd} | grep -q "state: Connected"; return $?; }
  connect() { 
    status || printf "%s\n" "connect ${vpnHost}" "${vpnGroup}" "${vpnUser}" "${vpnPass}" "y" | ${cmd}; return $?; }
  disconnect() { status && printf "disconnect" | ${cmd}; return $?; }

  eval ${cmdType}; status; return $?; }