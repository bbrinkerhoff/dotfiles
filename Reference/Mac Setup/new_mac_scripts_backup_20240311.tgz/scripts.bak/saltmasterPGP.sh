#!/bin/bash

installPGP() {
  read -ep "What is the host you would like to install PGP keys on? " saltmaster
  read -ep "What user would you like to use? " user
  while [[ -z $identityfile ]];do
    read -ep "What identity file would you like to use? " identityfile
    eval identityfile=$identityfile
    [[ ! -f $identityfile ]] && echo "'$identityfile' is not a valid path." && unset identityfile 
  done

  echo "${GREEN}Installing Salt PGP keys on the Salt Master '$saltmaster'...${RESET}"
  until grep -q 'PGP' <<< "$private" && grep -q 'PGP' <<< "$public";do
    local private=`lpass show -q --notes 698557145342898208 2>/dev/null`
    local public=`lpass show -q 3506046241910759981 --attach=att-3506046241910759981-46923 2>/dev/null`
  done
  ssh -l $user -i $identityfile $saltmaster "sudo mkdir /etc/salt/gpgkeys" >/dev/null 2>&1
  ssh -l $user -i $identityfile $saltmaster "echo '$private' > ~/SaltGPG-GCP && echo '$public' > ~/SaltGPG-GCP.pub" >/dev/null 2>&1
  ssh -l $user -i $identityfile $saltmaster "sudo mv ~$user/SaltGPG-GCP ~$user/SaltGPG-GCP.pub /etc/salt/gpgkeys/" >/dev/null 2>&1
  ssh -l $user -i $identityfile $saltmaster "sudo chmod -R 0700 /etc/salt/gpgkeys" >/dev/null 2>&1
  ssh -l $user -i $identityfile $saltmaster "sudo gpg --import --homedir /etc/salt/gpgkeys /etc/salt/gpgkeys/SaltGPG-GCP" >/dev/null 2>&1
  ssh -l $user -i $identityfile $saltmaster "sudo gpg --import --homedir /etc/salt/gpgkeys /etc/salt/gpgkeys/SaltGPG-GCP.pub" >/dev/null 2>&1
  ssh -l $user -i $identityfile $saltmaster "sudo rm -f ~/SaltGPG-GCP ~/SaltGPG-GCP.pub" >/dev/null 2>&1
  ssh -l $user -i $identityfile $saltmaster "sudo systemctl stop salt-master && sudo systemctl start salt-master" >/dev/null 2>&1
  echo "${GREEN}PGP keys have been installed on the Salt Master '$saltmaster'!${RESET}"; }

installPGP
exit 0
