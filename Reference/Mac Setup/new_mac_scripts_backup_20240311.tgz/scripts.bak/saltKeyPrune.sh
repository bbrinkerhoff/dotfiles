cleanKEYS() {
  local unresponsive=($(salt-run survey.hash \* test.ping|awk '/^ *True$/,EOF'|sed -E '/^ *- /!d;s/ *(- )?//g'))
  if [[ -n ${unresponsive[@]} ]];then
    for server in ${unresponsive[@]};do
      if ! ping -c 1 -w 2 ${server} >/dev/null 2>&1;then
        echo "${server} is unresponsive"
        salt-key -d ${server}
      fi
    done
  else
    echo "No offline minions found"
  fi
}

returnSERVERS() {
  for server in ${servers[@]};do
    local add=$(host ${server} | sed 's/.*address //g')
    for ip in ${IPS[@]};do
      if [[ ${add} == ${ip} ]];then
        echo "${server} with IP of ${add}"
      fi
    done
  done
}
