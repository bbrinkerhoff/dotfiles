#!/usr/local/bin/bash

################
## Color Vars ##
################
 R=$( tput -T xterm-256color setaf 1;tput -T xterm-256color bold);RED=${R}
 G=$( tput -T xterm-256color setaf 2;tput -T xterm-256color bold);GREEN=${G}
 Y=$( tput -T xterm-256color setaf 3;tput -T xterm-256color bold);YELLOW=${Y}
 B=$( tput -T xterm-256color setaf 4;tput -T xterm-256color bold);BLUE=${B}
RS=$( tput -T xterm-256color sgr0   ;tput -T xterm-256color bold);RESET=${RS}


###########################
## Text Output Functions ##
###########################
_info()  { local IFS=$'\n'; printf "${G} *  INFO${RS}: %s\n" $*;}      # echo 'INFO' text to stdout
_warn()  { local IFS=$'\n'; printf "${Y} *  WARN${RS}: %s\n" $*;}      # echo 'WARN' text to stdout
_error() { local IFS=$'\n'; printf "${R} * ERROR${RS}: %s\n" $* 1>&2;} # echo 'ERROR' text to stderr
_echo()  { local IFS=$'\n'; local clr=${1^^};[ ${!clr+x} ] && shift    #
                            printf "${!clr}%s\n${RS}" $*;}             # echo with specified color (if passed)
_join()  { local IFS=${1} ; shift;echo "$*";}                          # join arguments with ${1} delimiter


###################
## Menu Function ##
###################
menu() {
  local ESC=$(printf "\033")
  cursor_blink_on()  { printf "$ESC[?25h"; }
  cursor_blink_off() { printf "$ESC[?25l"; }
  cursor_to()        { printf "$ESC[$1;${2:-1}H"; }
  print_option()     { printf "   $1 "; }
  print_selected()   { printf "  $ESC[7m $1 $ESC[27m"; }
  get_cursor_row()   { IFS=';' read -sdR -p $'\E[6n' ROW COL; echo ${ROW#*[}; }
  key_input()        { read -s -n3 key 2>/dev/null >&2
                       if [[ $key = "$ESC[A" ]]; then echo up;    fi
                       if [[ $key = "$ESC[B" ]]; then echo down;  fi
                       if [[ $key = ""     ]]; then echo enter; fi; }
  for opt; do printf "\n"; done
  local lastrow=$(get_cursor_row)
  local startrow=$(($lastrow - $#))
  trap "cursor_blink_on; stty echo; printf '\n'; exit" 2
  cursor_blink_off
  local selected=0
  while true; do
      printf "\n"
      local idx=0
      for opt; do
          cursor_to $(($startrow + $idx))
          if [ $idx -eq $selected ]; then
              print_selected "$opt"
          else
              print_option "$opt"
          fi
          ((idx++))
      done
      case $(key_input) in
          enter) break;;
          up)    ((selected--));
                 if [ $selected -lt 0 ]; then local selected=$(($# - 1)); fi;;
          down)  ((selected++));
                 if [ $selected -ge $# ]; then local selected=0; fi;;
      esac
  done
  cursor_to $lastrow
  printf "\n"
  cursor_blink_on
  return $selected; }


###############
## Functions ##
###############
zipTGT() {
  while [[ -z ${targets[*]:+x} ]];do
    _echo blue "Which ut-prod-zipsms0X server would you like to close?"
    menu All ut-prod-zipsms0{1..3}; targets=($?)
    [[ ${targets} == 0 ]] && targets=({1..3})
  done
}

checkZipCB() { _info "CB Icinga2 check output for zipsms0${1:?No target provided}: $(ssh -qt ut-prod-zipsms0${1} 'sudo /etc/icinga2/plugins/check_sms_circuit_breaker.pl -v')"; }

closeZipSMSCB() {
  local creds="opsreadonly:$(lpass show -p 6924576371649996683)"
  _echo blue "Which ut-prod-zipsms0X server would you like to close?"
  menu All ut-prod-zipsms0{1..3}; local targets=($?)
  [[ ${targets} == 0 ]] && local targets=({1..3})

  _echo yellow "Closing SMS circuit-breakers on server(s): ${targets[*]}"
  for target in ${targets[*]};do
    local response=$(curl -s -o /dev/null -w "%{http_code}" -s -X PUT -u "${creds}" \
    "http://ut-prod-zipsms0${target}:8080/sms/internal/admin/circuit-breakers/${cbName:-bandwidth-rate-limit}/open" \
    -H "Content-Type: application/json" -d "false")
    _info "HTTP Response Code for zipsms0${target}: ${response}"
    checkZipCB ${target}
  done
}


##################
## Script Flags ##
##################
while test $# -gt 0;do
      case $1 in
              -c|--check)
                zipTGT
                for target in ${targets[*]};do
                  checkZipCB ${target}
                done
                exit $?
                ;;
              --name)
                shift
                cbName=${1}
                ;;
              *)
                targets=(${targets[*]} ${1})
                ;;
      esac
      shift
done

closeZipSMSCB
exit $?
