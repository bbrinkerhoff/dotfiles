#!/usr/bin/env bash

# Written by:
# Date written:
# Objective: 


#################
## Global Vars ##
#################
tmpFile=$(mktemp /tmp/XXXX.viewJSON.sh) path='.' data= key= clip=


###########################
## Text Output Functions ##
###########################
_txt()   { tput -T xterm-256color $@;}                                        # set text attributes
_fg()    { _txt setaf ${1};}                                                  # set the foreground text color
_bg()    { _txt setab ${1};}                                                  # set the background text color
_join()  { local IFS=${1} ; printf "${*:2}";}                                 # join arguments with ${1} delimiter
_info()  { local IFS=$'\n'; printf "${G} *  INFO${RS}: %s\n" "$*";}           # print 'INFO' text to stdout
_warn()  { local IFS=$'\n'; printf "${Y} *  WARN${RS}: %s\n" "$*";}           # print 'WARN' text to stdout
_error() { local IFS=$'\n'; printf "${R} * ERROR${RS}: %s\n" "$*" 1>&2;}      # print 'ERROR' text to stderr
_print() { local IFS=$'\n' c="${1^^}"; c="${!c}"                              # print arguments with an optional color arg
           shift 0${c:+1} ; printf "$c%b\n"                  "$*${RS}";}      #+to stdout separated by a newline


######################
## Text Output Vars ##
######################
BLD=$(_txt bold) DIM=$(_txt dim) # Bold / Dim
UL=$(_txt smul) ITL=$(_txt sitm) # Underline / Italic
RS=$(_txt sgr0)                  # Reset (Unset attributes)
R=$(_fg 9) G=$(_fg 10)             # Red / Green
B=$(_fg 12) Y=$(_fg 11)            # Blue / Yellow


###################
## Menu Function ##
###################
menu() {
  local ESC=$(printf "\033")
  cursor_blink_on()  { printf "%s" "${ESC}[?25h"                               ; }
  cursor_blink_off() { printf "%s" "${ESC}[?25l"                               ; }
  cursor_to()        { printf "%s" "${ESC}[$1;${2:-1}H"                        ; }
  print_option()     { printf "%s" "   $1 "                                    ; }
  print_selected()   { printf "%s" "  ${ESC}[7m $1 ${ESC}[27m"                 ; }
  get_cursor_row()   { IFS=';' read -rsdR -p $'\E[6n' ROW COL; echo "${ROW#*[}"; }
  key_input()        { read -rs -n3 key 2>/dev/null
                       if [[ "${key}" = "${ESC}[A" ]]; then echo up   ; fi
                       if [[ "${key}" = "${ESC}[B" ]]; then echo down ; fi
                       if [[ "${key}" = ""         ]]; then echo enter; fi     ; }
  for opt; do printf "\n"; done
  local lastrow=$(get_cursor_row)
  local startrow=$((lastrow - $#))
  [[ -z $(trap -p) ]] && trap "printf '\n\n'; handle_interrupt" 2
  cursor_blink_off
  local selected=0
  while true; do
      printf "\n"
      local idx=0
      for opt; do
          cursor_to $((startrow + idx))
          if [ ${idx} -eq ${selected} ]; then
              print_selected "${opt}"
          else
              print_option "${opt}"
          fi
          ((idx++))
      done
      case $(key_input) in
          enter) break;;
          up)    ((selected--));
                 if [ ${selected} -lt 0 ]; then local selected=$(($# - 1)); fi;;
          down)  ((selected++));
                 if [ ${selected} -ge $# ]; then local selected=0; fi;;
      esac
  done
  cursor_to "${lastrow}"
  printf "\n"
  cursor_blink_on
  return ${selected}; }


###############
## Functions ##
###############
handle_interrupt()
{
  local opts=(copy back exit)
  trap "rm -f ${tmpFile} &>/dev/null; cursor_blink_on; stty echo; printf '\n'; exit" 2
  _exit() { rm -f "${tmpFile}"; cursor_blink_on; stty echo; printf '\n'; exit; }
  _copy() { jq '.' "${tmpFile}" | pbcopy; _print G "${path} has been copied to clipboard."; _exit; }
  _back() { printf '\n\n'; browseData; }
  _print B "Would you like to copy the current key? (${path:-.})\n"
  menu copy back exit; opt=$?
  func="_${opts[${opt}]}"
  eval ${func}; return
}

getVARS()
{
  while [[ -z ${data} ]]
  do
    _print Y "Would you like to use a file or your clipboard as the datasource?\n\n"
    if menu file clipboard
    then
      _print Y "What is the file you would like to use? "; read -e file
      data="$(cat ${file})"
    else
      data="$(pbpaste)"
    fi
  done
}

browseData()
{
  _string()
  {
    printf '\n\n'
    if menu back copy
    then
      path="${path%.*}"
      return
    else
      jq '.' "${tmpFile}" | pbcopy
      _print G "Copied to clipboard."
      rm -f "${tmpFile}"
      stty echoctl
      exit $?
    fi
  }

  _array()
  {
    local keys length choice
    length="$(jq -r '.|length' "${tmpFile}")"
    if [[ ${length} -gt 0 ]]
    then
      keys=($(jq '.|keys|.[]' "${tmpFile}"))
      printf '\n\n'
      if [[ "${path}" == "." ]]
      then
        menu ${B}${keys[@]}${RS}; choice="$?"
      else
        menu ${B}${keys[@]}${RS} back; choice="$?"
        if [[ ${choice} -eq ${#keys[@]} ]]
        then
          path="${path%.*}"
          return
        fi
      fi
      path="${path}[${keys[$choice]//\'/}]"
      return
    else
      _print R "Array has no values."
      return
    fi
  }

  _object()
  {
    local keys length choice
    length="$(jq -r '.|length' "${tmpFile}")"
    if [[ ${length} -gt 0 ]]
    then
      local IFS=$'\n'
      keys=($(jq '.|keys|.[]' "${tmpFile}"))
      printf '\n\n'
      if [[ "${path}" == "." ]]
      then
        menu ${B}${keys[@]//\"/}${RS}; choice="$?"
      else
        menu ${B}${keys[@]//\"/}${RS} back; choice="$?"
        if [[ ${choice} -eq ${#keys[@]} ]]
        then
          path="${path%.*}"
          return
        fi
      fi
      path="${path}.${keys[${choice}]}"
      return
    else
      _print R "Dictionary has no values."
      return
    fi
  }

  _null() { _print R "Error getting key at path: ${path}"; handle_interrupt; }

  getVARS

  while true
  do
    local type
    path=$(sed 's/^/\./;s/^\.\.*/\./' <<< "${path:-.}")
    clear
    if jq "${path}" <<< "${data:-\[\]}" > "${tmpFile}" 2>/dev/null
    then
      jq '.' "${tmpFile}"
      type="_$(jq '.|type' "${tmpFile}")"
      eval "${type}"
    else
      _print R "Invalid JSON input."
      rm -f "${tmpFile}"
      stty echo
      exit $?
    fi
  done
}

#setVARS() {}
#functionONE() {}


###################
## Help Function ##
###################
showHELP() {
  echo "${YELLOW}Options:${BLUE}"
  echo "    -h,--help                         Show this help menu."
  echo "    -a,--arg                          Sets an arg."
  echo
  echo "${YELLOW}Usage:${BLUE}"
  echo "    ./script.sh"
  echo "    ./script.sh [-h,--help]"
  echo "    ./script.sh [-a,--arg][arg]"
  echo "${RESET}"; exit 0; }


##################
## Script Flags ##
##################
while test $# -gt 0;do
      case $1 in
              -h|--help)
                showHELP
                ;;
              *)
                if [[ $# -eq 2 ]]
                then
                  path="${1}"
                  shift
                  data="$(cat ${1})"
                elif [[ $# -eq 1 ]]
                then
                  path="${1}"
                fi
                ;;
      esac
      shift
done


browseData

stty echo; exit $?

