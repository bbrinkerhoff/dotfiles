installPGP() {
  echo "${GREEN}Installing Salt PGP keys on the Salt Master...${RESET}"
  local host=$1
  until grep -q 'PGP' <<< "$private" && grep -q 'PGP' <<< "$public";do
    local private=`lpass show -q --notes 698557145342898208 2>/dev/null`
    local public=`lpass show -q 3506046241910759981 --attach=att-3506046241910759981-46923 2>/dev/null`
  done
  ssh $host "sudo mkdir /etc/salt/gpgkeys" 
  ssh $host "echo '$private' > ~/SaltGPG-GCP && echo '$public' > ~/SaltGPG-GCP.pub" 
  ssh $host "sudo mv ~/SaltGPG-GCP ~/SaltGPG-GCP.pub /etc/salt/gpgkeys/" 
  ssh $host "sudo chmod -R 0700 /etc/salt/gpgkeys" 
  ssh $host "sudo gpg --import --homedir /etc/salt/gpgkeys /etc/salt/gpgkeys/SaltGPG-GCP" 
  ssh $host "sudo gpg --import --homedir /etc/salt/gpgkeys /etc/salt/gpgkeys/SaltGPG-GCP.pub" 
  ssh $host "sudo systemctl stop salt-master && sudo systemctl start salt-master" ; }
installPGP $@
