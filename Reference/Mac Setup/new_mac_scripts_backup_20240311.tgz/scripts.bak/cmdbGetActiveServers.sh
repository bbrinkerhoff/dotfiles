getActiveServers() {
  local pingOut host hosts=($*) onlineHosts=() offlineHosts=() nonHosts=() errHosts=()
  for host in ${hosts[@]}
  do
    ping -c1 -W 1500 ${host} &>/dev/null ; pingOut=$?
    if ((pingOut == 0))
    then
      onlineHosts+=(${host})

    elif ((pingOut == 2))
      then
        offlineHosts+=(${host})
    elif ((pingOut == 68))
      then
        nonHosts+=(${host})
    else
      errHosts+=("${host} - ${pingOut}")
    fi
  done

  [[ -n "${onlineHosts[@]}"  ]] && ( printf "${GREEN}Online Hosts:\n${RESET}"; printf "  - %s\n" ${onlineHosts[@]}   )
  [[ -n "${offlineHosts[@]}" ]] && ( printf "\n${RED}Offline Hosts:\n${RESET}"; printf "  - %s\n" ${offlineHosts[@]} )
  [[ -n "${nonHosts[@]}"     ]] && ( printf "\n${BLUE}Non Hosts:\n${RESET}"; printf "  - %s\n" ${nonHosts[@]}        )
  [[ -n "${errHosts[@]}"     ]] && ( printf "\n${YELLOW}Error Hosts:\n${RESET}"; printf "  - %s\n" ${errHosts[@]}    )
}