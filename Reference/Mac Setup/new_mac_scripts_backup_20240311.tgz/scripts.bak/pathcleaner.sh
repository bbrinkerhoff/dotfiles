#!/usr/bin/env bash

#!/usr/bin/env bash

# Written by:
# Date written:
# Objective: 


#################
## Global Vars ##
#################
VAR1=; VAR2=; ARR1=()


################
## Color Vars ##
################
 R=$( tput -T xterm-256color setaf 1;tput -T xterm-256color bold);RED=${R}
 G=$( tput -T xterm-256color setaf 2;tput -T xterm-256color bold);GREEN=${G}
 Y=$( tput -T xterm-256color setaf 3;tput -T xterm-256color bold);YELLOW=${Y}
 B=$( tput -T xterm-256color setaf 4;tput -T xterm-256color bold);BLUE=${B}
RS=$( tput -T xterm-256color sgr0   ;tput -T xterm-256color bold);RESET=${RS}


###########################
## Text Output Functions ##
###########################
_info()  { local IFS=$'\n'; printf "${G} *  INFO${RS}: %s\n" "$*";}      # print 'INFO' text to stdout
_warn()  { local IFS=$'\n'; printf "${Y} *  WARN${RS}: %s\n" "$*";}      # print 'WARN' text to stdout
_error() { local IFS=$'\n'; printf "${R} * ERROR${RS}: %s\n" "$*" 1>&2;} # print 'ERROR' text to stderr
_print() { local IFS=$'\n' c="${1^^}"; c="${!c}"                         # print arguments with an optional color arg
           shift 0${c:+1} ; printf "$c%b\n"                  "$*";}      #+to stdout separated by a newline
_join()  { local IFS=${1} ; printf "${*:2}";}                            # join arguments with ${1} delimiter


###################
## Menu Function ##
###################
menu() {
  local ESC=$(printf "\033")
  cursor_blink_on()  { printf "$ESC[?25h"; }
  cursor_blink_off() { printf "$ESC[?25l"; }
  cursor_to()        { printf "$ESC[$1;${2:-1}H"; }
  print_option()     { printf "   $1 "; }
  print_selected()   { printf "  $ESC[7m $1 $ESC[27m"; }
  get_cursor_row()   { IFS=';' read -sdR -p $'\E[6n' ROW COL; echo ${ROW#*[}; }
  key_input()        { read -s -n3 key 2>/dev/null >&2
                       if [[ $key = "$ESC[A" ]]; then echo up;    fi
                       if [[ $key = "$ESC[B" ]]; then echo down;  fi
                       if [[ $key = ""       ]]; then echo enter; fi; }
  for opt; do printf "\n"; done
  local lastrow=$(get_cursor_row)
  local startrow=$(($lastrow - $#))
  trap "cursor_blink_on; stty echo; printf '\n'; exit" 2
  cursor_blink_off
  local selected=0
  while true; do
      printf "\n"
      local idx=0
      for opt; do
          cursor_to $(($startrow + $idx))
          if [ $idx -eq $selected ]; then
              print_selected "$opt"
          else
              print_option "$opt"
          fi
          ((idx++))
      done
      case $(key_input) in
          enter) break;;
          up)    ((selected--));
                 if [ $selected -lt 0 ]; then local selected=$(($# - 1)); fi;;
          down)  ((selected++));
                 if [ $selected -ge $# ]; then local selected=0; fi;;
      esac
  done
  cursor_to $lastrow
  printf "\n"
  cursor_blink_on
  return $selected; }


###############
## Functions ##
###############
sanitizeFilePaths() {
  local tgtDir="${1%/}"; [[ -z ${tgtDir} ]] && echo "NO PATH PROVIDED" && return
  local destDir="$(sed 's/^\.\///;s/^\.//;s/\/$//' <<< "${tgtDir}")_stripped"
  local IFS=$'\n'
  local ogFiles=($(find "${tgtDir}" -type f ! -iname ".*"|sed 's/\.\///g;s/\/\//\//g'))
  local files=($(echo "${ogFiles[*]}"|perl -pe 's/(\.?\/) +(.*?)/$1$2/g;s/(.*?) +(\/)/$1$2/g'))
  local newDirs=($(for file in "${files[@]}";do dirname "${file}";done|sort -u))
  for dir in ${newDirs[@]};do
    mkdir -pv "${destDir}/${dir/\.\/}"
  done
  echo "${Y}PREVIEW OF CHANGES${RS}"
  local i=0
  for file in "${ogFiles[@]}";do
    echo "'${file}' -> '${destDir}/${files[${i}]}'"
    ((i++))
  done

  echo "${B}Continue?${RS}"
  if menu no yes
  then
    rm -vrf "${destDir}"
  else
    local i=0
    for file in "${ogFiles[@]}";do
      mv -v "${file}" "${destDir}/${files[${i}]}"
      ((i++))
    done
  fi
}














mkdir -pv 






}

###################
## Help Function ##
###################
showHELP() {
  echo "${YELLOW}Options:${BLUE}"
  echo "    -h,--help                         Show this help menu."
  echo "    -a,--arg                          Sets an arg."
  echo
  echo "${YELLOW}Usage:${BLUE}"
  echo "    ./script.sh"
  echo "    ./script.sh [-h,--help]"
  echo "    ./script.sh [-a,--arg][arg]"
  echo "${RESET}"; exit 0; }


##################
## Script Flags ##
##################
while test $# -gt 0;do
      case $1 in
              -h|--help)
                showHELP
                ;;
              -a|--arg)
                shift
                arg=${1}
                ;;
              *)
                _error "'$1' is not a valid argument."
                _info "A list of valid arguments can be found using -h or --help"
                exit 1
                ;;
      esac
      shift
done


#defaultFUNCTION # Run default function after script flags/args have been ingested
#exit 0 
