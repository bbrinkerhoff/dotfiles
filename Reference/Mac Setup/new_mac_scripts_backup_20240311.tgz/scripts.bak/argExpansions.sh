#!/bin/bash


IFS=${1}; shift; printf "IFS: %q\n" "${IFS}"
echo "\$@ (unquoted)"
echo $@
echo
echo "\$@ (quoted)"
echo "$@"
echo
echo "\$* (unquoted)"
echo $*
echo
echo "\$* (quoted)"
echo "$*"
