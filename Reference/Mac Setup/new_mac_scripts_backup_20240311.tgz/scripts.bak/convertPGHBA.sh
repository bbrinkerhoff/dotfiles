output=;
menu() {
  local ESC=$( printf "\033")
  cursor_blink_on()  { printf "$ESC[?25h"; }
  cursor_blink_off() { printf "$ESC[?25l"; }
  cursor_to()        { printf "$ESC[$1;${2:-1}H"; }
  print_option()     { printf "   $1 "; }
  print_selected()   { printf "  $ESC[7m $1 $ESC[27m"; }
  get_cursor_row()   { IFS=';' read -sdR -p $'\E[6n' ROW COL; echo ${ROW#*[}; }
  key_input()        { read -s -n3 key 2>/dev/null >&2
                       if [[ $key = "$ESC[A" ]]; then echo up;    fi
                       if [[ $key = "$ESC[B" ]]; then echo down;  fi
                       if [[ $key = ""     ]]; then echo enter; fi; }
  for opt; do printf "\n"; done
  local lastrow=$(get_cursor_row)
  local startrow=$(($lastrow - $#))
  trap "cursor_blink_on; stty echo; printf '\n'; exit" 2
  cursor_blink_off
  local selected=0
  while true; do
      printf "\n"
      local idx=0
      for opt; do
          cursor_to $(($startrow + $idx))
          if [ $idx -eq $selected ]; then
              print_selected "$opt"
          else
              print_option "$opt"
          fi
          ((idx++))
      done
      case $(key_input) in
          enter) break;;
          up)    ((selected--));
                 if [ $selected -lt 0 ]; then local selected=$(($# - 1)); fi;;
          down)  ((selected++));
                 if [ $selected -ge $# ]; then local selected=0; fi;;
      esac
  done
  cursor_to $lastrow
  printf "\n"
  cursor_blink_on
  return $selected; }

convertPG() {
  local template="
- name: %name%
  type: %type%
  database: %database%
  user: %user%
  address: %address%
  auth_method: %auth_method%"
  local IFS=$'\n'
  if [[ -z $@ ]];then
    echo "Paste/Enter the contents of the pg_hba.conf file you'd like to convert."
    echo "When done, enter only a period (.) on a new line and return."
    while read -e line;do
      [[ "$line" =~ ^\.$ ]] && break
      local lines=(${lines[@]} "$line")
    done
  else
      local lines=($@)
  fi
  _shift() { shift; echo $*; }
  output=$(
  for line in ${lines[@]};do
    local line=$(sed '/^ *#/d' <<< $line)
    if [[ -n $line ]];then
      local IFS=' '
      for key in type database user address auth_method name;do
        local value=$(awk '{ print $1 }' <<< "$line")
        [[ $key != "name" ]] && local value=$(sed 's/\(#\)\(^ \)$/\1 \2/g' <<< "$line" |awk '{ print $1 }'); eval $key=$value
        [[ $key == "name" ]] && local value="$(awk '{ print $0 }' <<< $(_shift $line))"; eval $key=\"$value\"
        local line=$(_shift $line)
      done
      sed -e "s;%name%;$name;g" -e "s;%type%;$type;g" -e "s;%database%;$database;g" -e "s;%user%;$user;g" -e "s;%address%;$address;g" -e "s;%auth_method%;$auth_method;g" <<< "$template"
    fi
  done); }

pg_hba() {
  convertPG
  if [[ -n ${output} ]];then
    echo "${output}"
    echo
    echo "Would you like to copy output to clipboard?"
    if ! menu no yes;then echo -n "${output}" | pbcopy;fi
  else
    echo "Error converting pg_hba.conf contents"
  fi; }

pg_hba $@
exit $?
