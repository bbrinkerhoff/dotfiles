minionInit() {
  echo "Installing 'screen'..."
  yum install screen -y --skip-broken
  echo "Testing enrollment..."
  salt-call test.ping
  read -p "Running salt-minion state. 1/3 hit enter when ready."
  salt-call state.sls modules.salt.minion --state-output=mixed
  read -p "Running salt-minion state. 2/3 hit enter when ready."
  salt-call state.sls modules.salt.minion --state-output=mixed
  read -p "Running salt-minion state. 3/3 hit enter when ready."
  salt-call state.sls modules.salt.minion --state-output=mixed
  local host=$(sed '/id:/!d;s/.*: //' /etc/salt/minion)
  local ping=$({ ping -c1 -w1 ${host}; } 2>&1)
  local ip=$(echo "${ping//$'\n'/}" | sed -E 's/.*\(([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)\).*/\1/g')
  while [[ -z ${ip+x} ]];do
    echo "Could not automatically find host's IP from DNS"
    read -ep "Please enter the desired host ip: " ip
  done
  read -p "Moving host (${host}) to IP '${ip}' with profile.network.ipv4 state. Hit enter when ready."
  salt-call state.sls profile.network.ipv4 pillar="{netbox: {primary_ip: {address: ${ip}/24}}}" -l debug
  echo
  echo "All commands have been run."
}

minionProvisionFirst() {
  echo "Upgrading all host packages..."
  yum upgrade -y --skip-broken
  echo "Running profile.common..."
  salt-call state.sls profile.common --state-output=mixed
  echo "Host is ready for restart."
}

minionProvisionSecond() {
  echo "Pruning extra kernels..."
  package-cleanup --oldkernels --count=2 -y
  echo "Running realmd state..."
  salt-call state.sls modules.realmd --state-output=mixed
  echo "Checking domain bind..."
  getent passwd adquery
  echo "Running profile.common..."
  salt-call state.sls profile.common,modules.bash,profile.common.Linux.authorized_keys --state-output=mixed
  echo "General configuration has completed."
}
